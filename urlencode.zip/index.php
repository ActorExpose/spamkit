<?php


if(isset($_GET['id'])){

if(isset($_GET["url"])){
$url = $_GET["url"];
if(strcasecmp(substr($url, 0, 4),"http")!==0){
 $url = "http://".$url; 
}
//echo $url."<br>";
//var_dump($_GET);
header("Location: ".$url);
return;
}else{

    header("HTTP/1.1 400 Bad Request");
    header("Status: 400 All rosy");
        
    return;
}



?>

