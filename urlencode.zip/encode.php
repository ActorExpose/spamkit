<?php

if(isset($_POST["url"])){
$url = $_POST["url"];
$url = str_replace("%Column_0%", "[==]", $url);
$encoded = join(array_map(function ($byte) { return "%$byte"; }, str_split(bin2hex($url), 2)));
$fullurl = "https://".getDomain()."/click?r=%_RTXT_7-8_1_%&amp;msgid=%_RTXT_5-5_1_%&amp;act=&amp;url=".str_replace("%5b%3d%3d%5d", "%Column_0%", $encoded)."&amp;cuid=prkk1mpz&amp;key=%_RTXT_28-35_a1_%";
}

function getDomain(){
$url=$_SERVER['SERVER_NAME'];
return $url;
}
?>
<html>
    <head>
        <title>Oseds</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12 pt-50" style="padding-top: 100px;">
                    <form action="#" method="post">
  <div class="form-group">
    <label for="email">Enter URL:</label>
    <input type="text" name="url" class="form-control" value="<?php echo $url; ?>" r="url" required="">
  </div>
  <div class="form-group">
    <label for="pwd">URL Encoded Result:</label>
    <input type="text" class="form-control" value="<?php echo $encoded; ?>" r="result">
  </div>
                          <div class="form-group">
    <label for="pwd">Base64 Encoded Result:</label>
    <input type="text" class="form-control" value="<?php echo base64_encode($url); ?>" r="result">
  </div>
                        
  <div class="form-group">
    <label for="pwd">Full url:</label>
    <input type="text" class="form-control" value="<?php echo $fullurl; ?>" r="result">
  </div>

  <button type="submit" class="btn btn-default" >Encode</button>
</form>
        </div>
            </div>
        </div>
        
        <script>
 function encodeNow(){
 console.log("we are here");    
     return false;
 }       
        </script>
    </body>
</html>
