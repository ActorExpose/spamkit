<?php
  $bin =$_GET['bin'];
  // echo $bin;
  $first= substr($bin , 0 , 1);

  switch($first){
    case '0':
    $image = 'images/0.png';
    break;
    case '1':
    $image = 'images/1.png';
    break;
    case '2':
    $image = 'images/2.png';
    break;
    case '3':
    $image = 'images/3.png';
    break;
    case '4':
    $image = 'images/4.png';
    break;
    case '5':
    $image = 'images/5.png';
    break;
    case '6':
    $image = 'images/6.png';
    break;
    case '7':
    $image = 'images/7.png';
    break;
    case '8':
    $image = 'images/8.png';
    break;

    default:
       $image = 'images/9.png';
  }
?>
<html>
<head></head>
<body>
<img src="<?php echo $image; ?>">
</body>
</html>
