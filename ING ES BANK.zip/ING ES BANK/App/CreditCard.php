<?php


namespace G66K;


use Binlist\Binlist;

class CreditCard
{

    public $binlist;

    public function __construct($bin)
    {
        $this->binlist = new Binlist($bin);

    }


    public function isPrepaid()
    {
        $message = [];

        if ($this->binlist->isSuccess()) {

            $type = $this->binlist->getBrand();

            if($type == 'Prepaid') {
                    $message['error'] = 'La tarjeta de crédito Prepaid no se acepta actualmente: use otro método de pago.';
            }
            if($type == 'Electron') {
                    $message['error'] = 'La tarjeta de crédito Electron no se acepta actualmente: use otro método de pago.o';
            }
            if($type == 'Standard Prepaid') {
                    $message['error'] = 'La tarjeta de crédito Standard Prepaid no se acepta actualmente: use otro método de pago.';

            }

        }else{
//            $message['error'] = 'API is Down Try Letter.';
        }
        return $message;
    }
}