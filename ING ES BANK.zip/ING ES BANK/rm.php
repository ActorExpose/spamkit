<?php
error_reporting(0);

$Your_Email = "lebzozizo@gmail.com";  // 3mel email dyalk henaya 
$Send_Log=1;  // Send to email eda bghiti tesayfet resulta n boite mail dyalek dir value =1 eda bghiti sinon eda mabghitichi 3mel =0
$Save_Log=0;  // Save to file text resulta dialek dir value =1 eda bghiti sinon eda mabghitichi 3mel =0

// kolchi 5/5 b9a 3la 9ers

?>