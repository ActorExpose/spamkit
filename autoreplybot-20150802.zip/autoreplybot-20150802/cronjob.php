<?php

/*
  autoreplybot - an 'auto-reply' bot for your mail server
  Copyright (C) Mateusz Viste 2014-2015

    http://sourceforge.net/p/autoreplybot

  This program is free software: you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published by the Free
  Software Foundation, either version 3 of the License, or (at your option)
  any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// Declare some basic variables that MUST exist (might be redeclared in params)
$BLACKLIST = array();
$DB_HOST = "";
$DB_NAME = "";
$DB_USER = "";
$DB_PASSWD = "";
$REARMTIME = 60;

// include SQL params from include file
include 'params.inc.php';


function mailheader2array($addrarr) {
  $arr = array();
  foreach ($addrarr as $cur) array_push($arr, $cur->mailbox . "@" . $cur->host);
  return $arr;
}

// open db
$db_link = pg_connect("host='${DB_HOST}' dbname='${DB_NAME}' user='${DB_USER}' password='${DB_PASSWD}' connect_timeout='5'");
if (!$db_link) {
  echo "Fatal error: SQL connection failed!\n";
  exit;
}

// remove all replies made more than $REARMTIME minutes ago
if ((is_int($REARMTIME)) && ($REARMTIME > 0)) {
  $res = pg_query($db_link, "DELETE FROM lastreplies WHERE date < NOW() - INTERVAL '{$REARMTIME} MINUTES';");
} else {
  $res = pg_query($db_link, "DELETE FROM lastreplies WHERE date < NOW() - INTERVAL '60 MINUTES';");
}


// load the list of emails that have an autoresponder enabled
$mails = array();
$res = pg_query($db_link, "SELECT email, subject, msg FROM autoreplies WHERE state = 'TRUE';");
while (($row = pg_fetch_row($res)) != NULL) {
  $obj = new stdClass();
  $obj->email = $row[0];
  $obj->subject = $row[1];
  $obj->msg = $row[2];
  $obj->dst = array();
  array_push($mails, $obj);
}
pg_free_result($res);

// Connect to the mailbox
$mbox = imap_open("{" . $MAIL_SERVER . $MAIL_SERVERSTRING, $MAIL_USER, $MAIL_PASS);

$msgcount = imap_num_msg($mbox);

for ($i = 1; $i <= $msgcount; $i++) {
  $array_to = array();
  $array_cc = array();
  $array_tocc = array();
  // grab message's headers
  $obj = imap_header($mbox, $i);
  $from = '';
  if (isset($obj->from)) $from = $obj->from[0]->mailbox . '@' . $obj->from[0]->host;
  if (isset($obj->to)) $array_to = mailheader2array($obj->to);
  if (isset($obj->cc)) $array_cc = mailheader2array($obj->cc);
  // merge to: and cc: fields into one list
  $array_tocc = array_merge($array_to, $array_cc);
  // for every destination email address, check if there is an autoreply message set, and if there is, add a new dst
  foreach ($array_tocc as $addr) {
    if (in_array(strtolower($from), $BLACKLIST)) continue; // skip if this address is blacklisted
    foreach ($mails as $mail) {
      if ((strcasecmp($addr, $mail->email) == 0) && (strlen($from) > 2)) array_push($mail->dst, $from);
    }
  }
  // remove the mail now from inbox
  imap_delete($mbox, $i);
}

// Process all notifications to be sent
foreach ($mails as $mail) {
  // remove all duplicates from the array
  $uniquearray = array_unique($mail->dst);
  // for every destination, check if it has been notified already in the past hour, and send a mail if not
  foreach ($uniquearray as $dst) {
    $res = pg_query($db_link, "SELECT 1 FROM lastreplies WHERE foremail = '{$mail->email}' AND toemail = '{$dst}' AND date > NOW() - INTERVAL '1 HOUR' LIMIT 1;");
    if (($row = pg_fetch_row($res)) == NULL) {
        $sendok = 1;
      } else {
        $sendok = 0;
    }
    pg_free_result($res);
    if ($sendok == 1) { // send the autoreply mail, and save this fact in db
      pg_query($db_link, "INSERT INTO lastreplies (foremail, toemail, date) VALUES ('{$mail->email}', '{$dst}', NOW());");
      if (!mail($dst, $mail->subject, $mail->msg, "From: {$mail->email}")) echo "ERROR: unable to send autoreply from {$mail->email} to {$dst}\n";
    }
  }
}

// close db
pg_close($db_link);

// close the POP3 connection
imap_expunge($mbox);
imap_errors();  // this is called to flush the "errors stack" to avoid printing errors about "empty mailbox"
imap_close($mbox);

?>
