<?php

/*
  autoreplybot - an 'auto-reply' bot for your mail server
  Copyright (C) Mateusz Viste 2014-2015

    http://sourceforge.net/p/autoreplybot

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// include SQL params from include file
include 'params.inc.php';

// Declare some variables
$notification = NULL;
$PVER = '20150802';
$HOMEPAGE = 'http://sourceforge.net/p/autoreplybot/';

// check for auth credentials
if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
  header('WWW-Authenticate: Basic realm="Authentication"');
  header('HTTP/1.1 401 Unauthorized');
  echo "<html><head><title>ACCESS DENIED</title></head><body>ACCESS DENIED</body></html>\n";
  exit;
}
$userlogin = $_SERVER['PHP_AUTH_USER'];
if (strpos($userlogin, '@') !== false) {
  $usermail = $userlogin;
} else {
  $usermail = $userlogin . "@" . $MAIL_DEFAULT_DOMAIN;
}
$userpass = $_SERVER['PHP_AUTH_PW'];

if ($LOGIN_AUTOCOMPLETE_DOMAIN == 1) $userlogin = $usermail;

// check that the auth is actually valid against the mail server
$mbox = imap_open("{" . $MAIL_SERVER . ":995/pop3/ssl/novalidate-cert}INBOX", $userlogin, $userpass);
if ($mbox === FALSE) {
  imap_close($mbox);
  sleep(2);
  header('WWW-Authenticate: Basic realm="Authentication"');
  header('HTTP/1.1 401 Unauthorized');
  echo "<html><head><title>ACCESS DENIED</title></head><body>ACCESS DENIED</body></html>\n";
  exit;
}
imap_close($mbox);

// open db
$db_link = pg_connect("host='${DB_HOST}' dbname='${DB_NAME}' user='${DB_USER}' password='${DB_PASSWD}' connect_timeout='5'");
if (!$db_link) {
  echo "<html><head>SQL Error</head><body>Fatal error: SQL connection failed!</body></html>\n";
  exit;
}

// if this is about an update, do the db update now
if (isset($_POST['msg']) && isset($_POST['subject'])) {
  // sanitize values we got
  $sqlsubject = pg_escape_string($db_link, $_POST['subject']);
  $sqlmsg = pg_escape_string($db_link, $_POST['msg']);
  if ((isset($_POST['state'])) && ($_POST['state'] == 'true')) {
    $sqlstate = 'TRUE';
  } else {
    $sqlstate = 'FALSE';
  }
  // remove existing field, if any, and insert new record (all in one transaction)
  pg_query($db_link, "BEGIN;");
  pg_query($db_link, "DELETE FROM autoreplies WHERE email='{$usermail}';");
  pg_query($db_link, "INSERT INTO autoreplies (state, email, subject, msg) VALUES ('{$sqlstate}', '{$usermail}', '{$sqlsubject}', '{$sqlmsg}');");
  if (pg_query($db_link, "COMMIT;") == NULL) $notification = "Data update failed";
}


// load db data
$state = 0;
$subject = "";
$msg = "";
$res = pg_query($db_link, "SELECT CASE WHEN state IS TRUE THEN 1 ELSE 0 END, subject, msg FROM autoreplies WHERE email = '{$usermail}';");
$row = pg_fetch_row($res);
if ($row != NULL) {
  $state = $row[0];
  $subject = $row[1];
  $msg = $row[2];
}
pg_free_result($res);


// close db
pg_close($db_link);


// output the html mess

echo "<!DOCTYPE html>\n";
echo "<html>\n";
echo "  <head>\n";
echo "    <title>autoreplybot</title>\n";
echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"style.css\">\n";
echo "  </head>\n";
echo "  <body>\n";
if ($notification != NULL) echo "    <p class=\"notif\">{$notification}</p>\n";
echo "    <form action=\"index.php\" method=\"post\">\n";
echo "    <table class=\"bigtable\">\n";
echo "      <tr>\n";
echo "        <td><p class=\"onoff\"><input type=\"checkbox\" name=\"state\" value=\"true\"" . ($state == 1 ? ' CHECKED' : '') . "> Autoresponder for <span class=\"mailaddr\">{$usermail}</span> on/off</p></td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td><p class=\"fieldtitle\">Subject</p><p style=\"margin-top: 0;\"><input type=\"text\" style=\"width: 98%\" name=\"subject\" placeholder=\"Write your subject here...\" value=\"{$subject}\"></p></td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td><p class=\"fieldtitle\">Message</p><textarea rows=\"12\" style=\"width: 98%\" name=\"msg\" placeholder=\"Write your auto-reply message here...\">{$msg}</textarea></td>\n";
echo "      </tr>\n";
echo "      <tr>\n";
echo "        <td style=\"text-align: center;\"><input type=\"submit\" value=\"Save\"></td>\n";
echo "      </tr>\n";
echo "    </table>\n";
echo "    </form>\n";
echo "    <p class=\"homelink\"><a class=\"homelink\" href=\"{$HOMEPAGE}\">autoreplybot v{$PVER}</a></p>\n";
echo "  </body>\n";
echo "</html>\n";

?>
