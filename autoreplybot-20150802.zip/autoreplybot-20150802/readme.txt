
  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
  *  autoreplybot - an 'auto-reply' bot for your e-mail server              *
  *                                                                         *
  *  Copyright (C) Mateusz Viste     http://sourceforge.net/p/autoreplybot  *
  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *


autoreplybot is designed for mail server administrators wishing to add an
easy-to-use, easy-to-implement and uninvasive "autoreply" service for their
users.

The concept is fairly simple:

  * You configure your mail server to send a copy of every mail that it
    processes to a specific mailbox
  * You set up autoreplybot to poll this mailbox
  * Users log on the autoreplybot web panel using their mailbox credentials
    (which autoreplybot validates against the mail server) and write their
    'out of office' messages in a simple html form
  * When one of your users configure an "out of office" reply, autoreplybot
    sends this message back to every person that write an email to the user.

A few features that make autoreplybot interesting:
  * You don't have to fiddle with your mail server
  * Once autoreplybot answers to someone, it won't re-send a new notification
    to this person for 1h (avoiding spamming your contacts) - this time is
    configurable via the $REARMTIME parameter in the configuration file
  * autoreplybot answers only to mails where the user's mail address appears
    in the to: or cc: fields, so it won't answer to mailing lists,
    newsletters, etc


=== INSTALLATION ===

First of all, to install autoreplybot you'll need:
  - a web server with PHP5 and following PHP modules: imap, postgresql
  - a postgresql database

Then:
  1. copy all *.php and *.css files to a web directory on your server

  2. prepare a PostgreSQL database for autoreplybot, and populate it using the
     db.sql schema:
      psql autoreplybot autoreplybot --password -h 127.0.0.1 -f db.sql

  3. rename params.inc.php.sample to params.inc.php and edit it accordingly to
     your environment

  4. schedule a cron job to call cronjob.php every minute (/etc/crontab):
     * *   * * *   root    php /srv/www/autoresponder/cronjob.php

  5. set your mail server to copy all incoming mails to the autoreplybot
     mailbox. On a Postfix system, this would be a matter of adding such
     directive to the main.cf configuration file:
   always_bcc = autoreplybot@mycorp.com

  6. point of your users to the web url where you copied autoreplybot php
     files. they should be able to authenticate there and set their autoreply
     messages.


=== LICENSE ===

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <http://www.gnu.org/licenses/>.
